# LiveKit voice calls

This Compose stack runs a single-node LiveKit server and Caddy TLS proxy. It is intended for foreground, one-to-one audio calls; it does not provide background/locked-screen ringing or TURN relay yet.

## VPS and DNS

- Use a public Linux VPS with a stable public IPv4 address. Start with at least 2 vCPU and 4 GB RAM, then size it from concurrent-call and network measurements.
- Create an `A` record such as `rtc.example.com` pointing to the VPS. TCP ports 80 and 443 must be reachable so Caddy can obtain and renew a TLS certificate.
- Allow inbound TCP 7881 and UDP 50000-60000 in both the VPS firewall and hosting-provider firewall/security group. Caddy proxies the WebSocket/API port 7880 over HTTPS/WSS; it is not published directly.
- UDP 443 is exposed for HTTP/3 by Caddy but is optional. TURN ports 3478/UDP and 5349/TCP are not enabled in this initial configuration; add and configure TURN if calls fail on restrictive networks.

## Configure and start

1. Copy `server/.env.example` to `server/.env` if the backend environment file does not exist. Keep `.env` private and set `LIVEKIT_DOMAIN` and `LIVEKIT_URL` to the DNS name above, for example `rtc.example.com` and `wss://rtc.example.com`.
2. Generate a unique API key and secret, for example with `openssl rand -hex 16` and `openssl rand -hex 32`. Put the results in `LIVEKIT_API_KEY` and `LIVEKIT_API_SECRET` in `server/.env`. The secret must remain on the VPS/backend and must never be added to the iOS app.
3. From `server/livekit/`, start the RTC stack with `docker compose --env-file ../.env up -d`. Check it with `docker compose ps` and `docker compose logs --tail=100 livekit proxy`.
4. Configure the Spring Boot backend with the same `LIVEKIT_URL`, `LIVEKIT_API_KEY`, and `LIVEKIT_API_SECRET` in `server/.env`, then restart the backend. Rebuild/relaunch the iOS app from Xcode so it resolves the LiveKit Swift package.
5. Confirm the certificate is valid at `https://rtc.example.com` and verify that both test devices are on separate networks. Place a call while the app is foregrounded on both devices.

The backend issues short-lived room-scoped participant tokens only after validating the app's server-issued session. Session tokens are stored in the iOS Keychain; LiveKit credentials are never embedded in the app. Existing installations must sign in again once to receive a session token.

## Operations

Use `docker compose --env-file ../.env pull` and `docker compose --env-file ../.env up -d` to update the pinned LiveKit/Caddy images. Back up Caddy's `caddy_data` volume if retaining certificate state matters. Rotating the API key requires updating both the LiveKit Compose environment and the Spring Boot environment, then restarting both services.
