import Foundation
import Combine

@MainActor
class AuthViewModel: ObservableObject {
    @Published var email = ""
    @Published var password = ""
    @Published var name = ""
    
    @Published var isRegisterMode = false
    @Published var isLoading = false
    @Published var alertMessage: String?
    @Published var showAlert = false
    
    func submit() {
        guard !email.isEmpty, !password.isEmpty else {
            showAlert(message: "メールアドレスとパスワードを入力してください")
            return
        }
        
        isLoading = true
        
        Task {
            do {
                if isRegisterMode {
                    guard !name.isEmpty else {
                        showAlert(message: "名前を入力してください")
                        isLoading = false
                        return
                    }
                    let req = RegisterRequest(email: email, password: password, name: name)
                    let res = try await APIClient.shared.register(request: req)
                    
                    if let userId = res.userId, let sessionToken = res.sessionToken {
                        try AppSession.shared.logIn(userId: userId, sessionToken: sessionToken)
                    } else {
                        showAlert(message: "ログインセッションを取得できませんでした。もう一度お試しください。")
                    }
                } else {
                    let req = LoginRequest(email: email, password: password)
                    let res = try await APIClient.shared.login(request: req)
                    
                    if let userId = res.userId, let sessionToken = res.sessionToken {
                        try AppSession.shared.logIn(userId: userId, sessionToken: sessionToken)
                    } else {
                        showAlert(message: "ログインセッションを取得できませんでした。もう一度お試しください。")
                    }
                }
            } catch {
                showAlert(message: error.localizedDescription)
            }
            isLoading = false
        }
    }
    
    private func showAlert(message: String) {
        self.alertMessage = message
        self.showAlert = true
    }
}
