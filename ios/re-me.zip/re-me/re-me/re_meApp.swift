import SwiftUI

@main
struct re_meApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    @StateObject private var session = AppSession.shared
    @Environment(\.scenePhase) private var scenePhase
    
    var body: some Scene {
        WindowGroup {
            Group {
                if session.isLoggedIn {
                    MainTabView()
                } else {
                    ContentView()
                }
            }
            .onAppear {
                if let userId = session.currentUserId {
                    PushNotificationManager.shared.registerIfNeeded(userId: userId)
                }
                updateMessageSocket()
            }
            .onChange(of: session.currentUserId) { oldUserId, newUserId in
                if let oldUserId, oldUserId != newUserId {
                    PushNotificationManager.shared.unregister(userId: oldUserId)
                }
                if let newUserId {
                    PushNotificationManager.shared.registerIfNeeded(userId: newUserId)
                }
                updateMessageSocket()
            }
            .onChange(of: scenePhase) { _, newPhase in
                if newPhase == .active, let userId = session.currentUserId {
                    PushNotificationManager.shared.registerIfNeeded(userId: userId)
                }
                updateMessageSocket()
            }
            .onChange(of: CallManager.shared.callScreen?.id) { _, _ in
                updateMessageSocket()
            }
        }
    }

    private func updateMessageSocket() {
        let callIsActive = CallManager.shared.callScreen != nil
        guard (scenePhase == .active || callIsActive),
              let userId = session.currentUserId,
              let sessionToken = session.sessionToken else {
            MessageSocket.shared.disconnect()
            return
        }
        MessageSocket.shared.connect(userId: userId, sessionToken: sessionToken)
    }
}
