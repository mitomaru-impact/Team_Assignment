import Combine
import Foundation

@MainActor
final class MessageSocket: ObservableObject {
    static let shared = MessageSocket()

    @Published private(set) var latestMessage: MessageDto?
    @Published private(set) var latestMessageRevision = 0
    @Published private(set) var readReceiptEvent: ReadReceiptEvent?
    @Published private(set) var readReceiptRevision = 0
    @Published private(set) var conversationReadRevision = 0
    @Published private(set) var conversationDeletionRevision = 0
    @Published private(set) var conversationDeletionEvent: ConversationDeletionEvent?
    @Published private(set) var profileIdentityRevision = 0
    @Published private(set) var profileIdentityEvent: ProfileIdentityEvent?
    @Published private(set) var groupChangeRevision = 0
    @Published private(set) var groupChangeEvent: GroupChangeEvent?
    @Published private(set) var messageReactionRevision = 0
    @Published private(set) var messageReactionEvent: MessageReactionEvent?
    @Published private(set) var messageRecallRevision = 0
    @Published private(set) var messageRecallEvent: MessageRecallEvent?
    @Published private(set) var typingRevision = 0
    @Published private(set) var typingEvent: TypingEvent?

    private(set) var activeConversationEmail: String?
    private(set) var activeGroupId: String?
    private var userId: String?
    private var sessionToken: String?
    private var webSocketTask: URLSessionWebSocketTask?
    private var receiveTask: Task<Void, Never>?
    private var reconnectTask: Task<Void, Never>?
    private var heartbeatTask: Task<Void, Never>?
    private var readySocket: URLSessionWebSocketTask?
    private var isActive = false

    private init() {}

    func conversationDidBecomeRead() {
        conversationReadRevision += 1
    }

    func setActiveConversation(email: String) {
        activeConversationEmail = email
        activeGroupId = nil
    }

    func clearActiveConversation(email: String) {
        guard activeConversationEmail?.caseInsensitiveCompare(email) == .orderedSame else { return }
        activeConversationEmail = nil
    }

    func setActiveGroupConversation(id: String) {
        activeGroupId = id
        activeConversationEmail = nil
    }

    func clearActiveGroupConversation(id: String) {
        guard activeGroupId == id else { return }
        activeGroupId = nil
    }

    func conversationWasDeleted() {
        conversationDeletionRevision += 1
    }

    func sendCallSignal(_ payload: CallSignalPayload) async throws {
        let data = try JSONEncoder().encode(payload)
        guard let text = String(data: data, encoding: .utf8) else {
            throw URLError(.cannotDecodeContentData)
        }
        let socket = try await waitUntilConnected()
        do {
            try await socket.send(.string(text))
        } catch {
            invalidate(socket)
            throw error
        }
    }

    func sendTypingSignal(targetEmail: String?, groupId: String?, isTyping: Bool) async throws {
        let payload = TypingSignalPayload(
            type: "typing",
            targetEmail: targetEmail,
            groupId: groupId,
            isTyping: isTyping)
        let data = try JSONEncoder().encode(payload)
        guard let text = String(data: data, encoding: .utf8) else {
            throw URLError(.cannotDecodeContentData)
        }
        let socket = try await waitUntilConnected()
        do {
            try await socket.send(.string(text))
        } catch {
            invalidate(socket)
            throw error
        }
    }

    func waitUntilConnected() async throws -> URLSessionWebSocketTask {
        guard isActive else {
            throw URLError(.notConnectedToInternet)
        }

        for _ in 0..<30 {
            guard isActive else { throw URLError(.cancelled) }
            if let socket = webSocketTask {
                if readySocket === socket {
                    return socket
                }

                do {
                    try await ping(socket)
                    guard isActive, webSocketTask === socket else {
                        throw URLError(.cancelled)
                    }
                    readySocket = socket
                    return socket
                } catch {
                    guard isActive else { throw error }
                    invalidate(socket)
                }
            }
            try await Task.sleep(for: .milliseconds(500))
        }
        throw URLError(.timedOut)
    }

    private func invalidate(_ socket: URLSessionWebSocketTask) {
        guard webSocketTask === socket else { return }
        socket.cancel(with: .goingAway, reason: nil)
        webSocketTask = nil
        readySocket = nil
        scheduleReconnect()
    }

    private func ping(_ socket: URLSessionWebSocketTask) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            socket.sendPing { error in
                if let error {
                    continuation.resume(throwing: error)
                } else {
                    continuation.resume()
                }
            }
        }
    }

    func connect(userId: String, sessionToken: String) {
        if self.userId == userId,
           self.sessionToken == sessionToken,
           (webSocketTask != nil || reconnectTask != nil) {
            return
        }
        disconnect()
        self.userId = userId
        self.sessionToken = sessionToken
        isActive = true
        openConnection()
    }

    func disconnect() {
        isActive = false
        userId = nil
        sessionToken = nil
        reconnectTask?.cancel()
        reconnectTask = nil
        receiveTask?.cancel()
        receiveTask = nil
        heartbeatTask?.cancel()
        heartbeatTask = nil
        webSocketTask?.cancel(with: .normalClosure, reason: nil)
        webSocketTask = nil
        readySocket = nil
    }

    private func openConnection() {
        guard isActive, let userId = userId, let sessionToken,
              let url = APIClient.shared.messageWebSocketURL(userId: userId) else {
            return
        }

        var request = URLRequest(url: url)
        request.timeoutInterval = 15
        request.setValue("Bearer \(sessionToken)", forHTTPHeaderField: "Authorization")
        request.setValue("true", forHTTPHeaderField: "ngrok-skip-browser-warning")
        let socket = URLSession.shared.webSocketTask(with: request)
        webSocketTask = socket
        socket.resume()
        heartbeatTask?.cancel()
        heartbeatTask = Task { [weak self, weak socket] in
            guard let self, let socket else { return }
            await self.keepAlive(socket)
        }
        receiveTask = Task { [weak self] in
            await self?.receiveMessages(from: socket)
        }
    }

    private func keepAlive(_ socket: URLSessionWebSocketTask) async {
        while !Task.isCancelled, isActive, webSocketTask === socket {
            do {
                try await Task.sleep(for: .seconds(20))
                try await ping(socket)
            } catch {
                guard !Task.isCancelled, isActive, webSocketTask === socket else { return }
                invalidate(socket)
                return
            }
        }
    }

    private func receiveMessages(from socket: URLSessionWebSocketTask) async {
        do {
            while !Task.isCancelled {
                let frame = try await socket.receive()
                let data: Data
                switch frame {
                case .data(let receivedData):
                    data = receivedData
                case .string(let text):
                    data = Data(text.utf8)
                @unknown default:
                    continue
                }

                if let event = try? JSONDecoder().decode(ReadReceiptEvent.self, from: data),
                   event.type == "read_receipt" {
                    readReceiptEvent = event
                    readReceiptRevision += 1
                } else if let event = try? JSONDecoder().decode(ConversationDeletionEvent.self, from: data),
                   event.type == "conversation_deleted" {
                    conversationDeletionEvent = event
                    conversationWasDeleted()
                } else if let event = try? JSONDecoder().decode(ProfileIdentityEvent.self, from: data),
                          event.type == "profile_identity_changed" {
                    profileIdentityEvent = event
                    profileIdentityRevision += 1
                } else if let event = try? JSONDecoder().decode(GroupChangeEvent.self, from: data),
                          event.type.hasPrefix("group_") {
                    groupChangeEvent = event
                    groupChangeRevision += 1
                } else if let event = try? JSONDecoder().decode(MessageReactionEvent.self, from: data),
                          event.type == "message_reaction_changed" {
                    messageReactionEvent = event
                    messageReactionRevision += 1
                } else if let event = try? JSONDecoder().decode(MessageRecallEvent.self, from: data),
                          event.type == "message_recalled" {
                    messageRecallEvent = event
                    messageRecallRevision += 1
                    PushNotificationManager.shared.clearMessageNotifications(messageIds: [event.messageId])
                } else if let event = try? JSONDecoder().decode(TypingEvent.self, from: data),
                          event.type == "typing" {
                    typingEvent = event
                    typingRevision += 1
                } else if let event = try? JSONDecoder().decode(CallSignalingEvent.self, from: data),
                          ["incoming_call", "call_accepted", "call_declined", "call_ended",
                           "call_offer", "call_answer", "ice_candidate", "call_signal_error"].contains(event.type) {
                    CallManager.shared.handle(event)
                } else {
                    let message = try JSONDecoder().decode(MessageDto.self, from: data)
                    latestMessage = message
                    latestMessageRevision += 1
                    PushNotificationManager.shared.handleForegroundMessage(message)
                }
            }
        } catch {
            guard !Task.isCancelled, webSocketTask === socket else { return }
            socket.cancel(with: .goingAway, reason: nil)
            webSocketTask = nil
            readySocket = nil
            scheduleReconnect()
        }
    }

    struct ConversationDeletionEvent: Decodable {
        let type: String
        let partnerEmail: String
        let forceClose: Bool
    }

    struct ReadReceiptEvent: Decodable {
        let type: String
        let readerId: String
        let messageIds: [Int64]
    }

    struct ProfileIdentityEvent: Decodable {
        let type: String
        let partnerEmail: String
    }

    struct GroupChangeEvent: Decodable {
        let type: String
        let groupId: String
        let userId: String?
    }

    struct MessageReactionEvent: Decodable {
        let type: String
        let groupId: String?
        let partnerEmail: String?
    }

    struct MessageRecallEvent: Decodable {
        let type: String
        let messageId: Int64
        let groupId: String?
        let partnerEmail: String?
    }

    struct TypingEvent: Decodable {
        let type: String
        let senderId: String
        let groupId: String?
        let partnerEmail: String?
        let isTyping: Bool
    }

    struct CallSignalingEvent: Decodable, Equatable {
        let type: String
        let callId: String?
        let callerEmail: String?
        let callerName: String?
        let peerName: String?
        let sdp: String?
        let candidate: String?
        let sdpMid: String?
        let sdpMLineIndex: Int?
        let message: String?
    }

    struct CallSignalPayload: Encodable {
        let type: String
        let callId: String
        let sdp: String?
        let candidate: String?
        let sdpMid: String?
        let sdpMLineIndex: Int?

        init(
            type: String,
            callId: String,
            sdp: String? = nil,
            candidate: String? = nil,
            sdpMid: String? = nil,
            sdpMLineIndex: Int? = nil
        ) {
            self.type = type
            self.callId = callId
            self.sdp = sdp
            self.candidate = candidate
            self.sdpMid = sdpMid
            self.sdpMLineIndex = sdpMLineIndex
        }
    }

    private struct TypingSignalPayload: Encodable {
        let type: String
        let targetEmail: String?
        let groupId: String?
        let isTyping: Bool
    }

    private func scheduleReconnect() {
        guard isActive, reconnectTask == nil else { return }
        reconnectTask = Task { [weak self] in
            try? await Task.sleep(for: .seconds(2))
            guard !Task.isCancelled, let self, self.isActive else { return }
            self.reconnectTask = nil
            self.openConnection()
        }
    }
}
