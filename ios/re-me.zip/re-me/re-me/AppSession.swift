import Foundation
import Combine
import Security

@MainActor
class AppSession: ObservableObject {
    static let shared = AppSession()
    
    // ログイン状態フラグ（変化すると自動で画面が再描画されます）
    @Published var isLoggedIn: Bool = false
    @Published var currentUserId: String? = nil
    @Published private(set) var sessionToken: String?
    
    private let userIdKey = "loggedInPublicUserId"
    private let tokenService = "com.reme.re-me.session"
    private let tokenAccount = "session-token"
    
    init() {
        UserDefaults.standard.removeObject(forKey: "loggedInUserId")
        if let userId = UserDefaults.standard.string(forKey: userIdKey),
           let token = readSessionToken() {
            self.currentUserId = userId
            self.sessionToken = token
            self.isLoggedIn = true
        } else {
            UserDefaults.standard.removeObject(forKey: userIdKey)
            deleteSessionToken()
            self.isLoggedIn = false
        }
    }
    
    // ログイン成功時に呼び出す
    func logIn(userId: String, sessionToken: String) throws {
        try saveSessionToken(sessionToken)
        UserDefaults.standard.set(userId, forKey: userIdKey)
        self.currentUserId = userId
        self.sessionToken = sessionToken
        self.isLoggedIn = true
    }
    
    // ログアウト時に呼び出す
    func logOut() {
        let tokenToRevoke = sessionToken
        let userIdToUnregister = currentUserId
        if let tokenToRevoke {
            Task {
                if let userIdToUnregister {
                    await PushNotificationManager.shared.unregisterVoipToken(
                        userId: userIdToUnregister,
                        sessionToken: tokenToRevoke)
                }
                await CallManager.shared.endCallAndWait(sessionToken: tokenToRevoke)
                do {
                    try await APIClient.shared.revokeSession(sessionToken: tokenToRevoke)
                } catch {
                    NSLog("Failed to revoke login session: %@", error.localizedDescription)
                }
            }
        }
        UserDefaults.standard.removeObject(forKey: userIdKey)
        deleteSessionToken()
        self.sessionToken = nil
        self.currentUserId = nil
        self.isLoggedIn = false
    }

    private func readSessionToken() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: tokenService,
            kSecAttrAccount as String: tokenAccount,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    private func saveSessionToken(_ token: String) throws {
        deleteSessionToken()
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: tokenService,
            kSecAttrAccount as String: tokenAccount,
            kSecValueData as String: Data(token.utf8),
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        let status = SecItemAdd(query as CFDictionary, nil)
        guard status == errSecSuccess else {
            throw NSError(domain: NSOSStatusErrorDomain, code: Int(status))
        }
    }

    private func deleteSessionToken() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: tokenService,
            kSecAttrAccount as String: tokenAccount
        ]
        SecItemDelete(query as CFDictionary)
    }
}
