import SwiftUI

struct GroupMemberManagementView: View {
    @Environment(\.dismiss) private var dismiss

    let userId: String
    let groupId: String
    let profileId: Int64?

    @State private var members: [GroupMemberDto] = []
    @State private var contacts: [GroupContactDto] = []
    @State private var selectedContactIds: Set<String> = []
    @State private var memberToRemove: GroupMemberDto?
    @State private var isLoading = true
    @State private var isSaving = false
    @State private var errorMessage: String?

    private var isCreator: Bool {
        members.first(where: { $0.publicUserId == userId })?.creator ?? false
    }

    private var availableContacts: [GroupContactDto] {
        contacts.filter { contact in
            !members.contains(where: { $0.publicUserId == contact.publicUserId })
        }
    }

    var body: some View {
        List {
            Section("メンバー") {
                if isLoading {
                    ProgressView("メンバーを読み込み中")
                } else {
                    ForEach(members) { member in
                        HStack {
                            VStack(alignment: .leading, spacing: 3) {
                                Text(member.displayName)
                                    .foregroundStyle(.primary)
                                Text(member.email)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                            Spacer()
                            if member.creator {
                                Text("作成者")
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            } else if isCreator {
                                Button(role: .destructive) {
                                    memberToRemove = member
                                } label: {
                                    Image(systemName: "minus.circle")
                                }
                                .accessibilityLabel("\(member.displayName)を削除")
                            }
                        }
                    }
                }
            }

            if isCreator, profileId != nil {
                Section {
                    if availableContacts.isEmpty {
                        Text("追加できる連絡先はありません。")
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(availableContacts) { contact in
                            Button {
                                if selectedContactIds.contains(contact.publicUserId) {
                                    selectedContactIds.remove(contact.publicUserId)
                                } else {
                                    selectedContactIds.insert(contact.publicUserId)
                                }
                            } label: {
                                HStack {
                                    Text(contact.displayName)
                                        .foregroundStyle(.primary)
                                    Spacer()
                                    Image(systemName: selectedContactIds.contains(contact.publicUserId)
                                          ? "checkmark.circle.fill" : "circle")
                                        .foregroundStyle(selectedContactIds.contains(contact.publicUserId)
                                                         ? Color.accentColor : Color.secondary)
                                }
                            }
                            .buttonStyle(.plain)
                        }
                    }

                    if !availableContacts.isEmpty {
                        Button("選択したメンバーを追加", systemImage: "person.badge.plus") {
                            addSelectedMembers()
                        }
                        .disabled(selectedContactIds.isEmpty || isSaving)
                    }
                } header: {
                    Text("メンバーを追加")
                }
            } else if isCreator && profileId == nil {
                Section {
                    Text("メンバーを追加するには、プロファイルの連絡先からグループを開いてください。")
                        .foregroundStyle(.secondary)
                }
            }

            if let errorMessage {
                Section {
                    Text(errorMessage)
                        .foregroundStyle(.red)
                }
            }
        }
        .navigationTitle("メンバー管理")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("完了") { dismiss() }
            }
        }
        .confirmationDialog(
            "「\(memberToRemove?.displayName ?? "")」をグループから削除しますか？",
            isPresented: Binding(
                get: { memberToRemove != nil },
                set: { if !$0 { memberToRemove = nil } }),
            titleVisibility: .visible
        ) {
            Button("メンバーを削除", role: .destructive) {
                removeSelectedMember()
            }
            Button("キャンセル", role: .cancel) {
                memberToRemove = nil
            }
        }
        .task {
            await loadData()
        }
    }

    @MainActor
    private func loadData() async {
        isLoading = true
        do {
            members = try await APIClient.shared.fetchGroupMembers(userId: userId, groupId: groupId)
            if let profileId, members.contains(where: { $0.publicUserId == userId && $0.creator }) {
                contacts = try await APIClient.shared.fetchGroupContacts(userId: userId, profileId: profileId)
            }
            errorMessage = nil
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    private func addSelectedMembers() {
        let selectedIds = Array(selectedContactIds)
        guard !selectedIds.isEmpty else { return }
        isSaving = true
        Task {
            do {
                try await APIClient.shared.addGroupMembers(
                    userId: userId,
                    groupId: groupId,
                    publicUserIds: selectedIds)
                selectedContactIds.removeAll()
                await loadData()
            } catch {
                errorMessage = error.localizedDescription
            }
            isSaving = false
        }
    }

    private func removeSelectedMember() {
        guard let member = memberToRemove else { return }
        isSaving = true
        Task {
            do {
                try await APIClient.shared.removeGroupMember(
                    userId: userId,
                    groupId: groupId,
                    memberPublicId: member.publicUserId)
                memberToRemove = nil
                await loadData()
            } catch {
                errorMessage = error.localizedDescription
            }
            isSaving = false
        }
    }
}
