import Combine
import Foundation
import OSLog
import PushKit
import UIKit
import UserNotifications

@MainActor
final class PushNotificationManager: ObservableObject {
    static let shared = PushNotificationManager()

    @Published private(set) var tappedChatEmail: String?
    @Published private(set) var tappedGroupId: String?
    @Published private(set) var unclassifiedNotificationRevision = 0

    private let tokenKey = "apnsDeviceToken"
    private let voipTokenKey = "voipDeviceToken"
    private let logger = Logger(subsystem: Bundle.main.bundleIdentifier ?? "ReMe", category: "push")
    private var currentUserId: String?

    private init() {}

    func registerIfNeeded(userId: String) {
        let alreadyRegistered = currentUserId == userId
        currentUserId = userId
        syncDeviceToken(for: userId)
        syncVoipToken(for: userId)
        refreshUnreadBadge(userId: userId)
        guard !alreadyRegistered else { return }

        Task {
            let center = UNUserNotificationCenter.current()
            do {
                let settings = await center.notificationSettings()
                if settings.authorizationStatus == .notDetermined {
                    let granted = try await center.requestAuthorization(options: [.alert, .badge, .sound])
                    guard granted else { return }
                } else if settings.authorizationStatus == .denied {
                    return
                }
                UIApplication.shared.registerForRemoteNotifications()
            } catch {
                logger.error("Push notification permission request failed: \(error.localizedDescription, privacy: .public)")
            }
        }
    }

    func unregister(userId: String) {
        if currentUserId == userId {
            currentUserId = nil
            setAppBadgeCount(0)
        }
        if let deviceToken = UserDefaults.standard.string(forKey: tokenKey) {
            Task {
                do {
                    try await APIClient.shared.unregisterAPNsToken(userId: userId, deviceToken: deviceToken)
                } catch {
                    logger.error("APNs token unregister failed: \(error.localizedDescription, privacy: .public)")
                }
            }
        }
        let sessionToken = AppSession.shared.sessionToken
        Task {
            await unregisterVoipToken(userId: userId, sessionToken: sessionToken)
        }
    }

    func didRegister(deviceToken: String) {
        UserDefaults.standard.set(deviceToken, forKey: tokenKey)
        logger.info("APNs registered this device")
        if let currentUserId {
            syncDeviceToken(for: currentUserId)
        }
    }

    func didRegisterVoipToken(_ deviceToken: String) {
        UserDefaults.standard.set(deviceToken, forKey: voipTokenKey)
        if let currentUserId {
            syncVoipToken(for: currentUserId)
        }
    }

    func didInvalidateVoipToken() {
        UserDefaults.standard.removeObject(forKey: voipTokenKey)
    }

    func receivedIncomingCallPush(_ userInfo: [AnyHashable: Any], completion: @escaping () -> Void) {
        guard let callId = userInfo["callId"] as? String,
              let callerEmail = userInfo["callerEmail"] as? String,
              !callId.isEmpty,
              !callerEmail.isEmpty else {
            logger.error("VoIP push did not contain callId and callerEmail")
            completion()
            return
        }

        if let userId = AppSession.shared.currentUserId,
           let sessionToken = AppSession.shared.sessionToken {
            MessageSocket.shared.connect(userId: userId, sessionToken: sessionToken)
        }
        CallManager.shared.receiveIncomingCall(
            callId: callId,
            callerEmail: callerEmail,
            callerName: userInfo["callerName"] as? String ?? callerEmail,
            completion: completion)
    }

    func unregisterVoipToken(userId: String, sessionToken: String?) async {
        guard let deviceToken = UserDefaults.standard.string(forKey: voipTokenKey),
              let sessionToken else { return }
        do {
            try await APIClient.shared.unregisterVoipToken(
                sessionToken: sessionToken,
                deviceToken: deviceToken)
            didInvalidateVoipToken()
        } catch {
            logger.error("VoIP token unregister failed for \(userId): \(error.localizedDescription, privacy: .public)")
        }
    }

    func openChatFromNotification(userInfo: [AnyHashable: Any]) {
        if userInfo["unclassified"] as? Bool == true {
            tappedChatEmail = nil
            tappedGroupId = nil
            unclassifiedNotificationRevision += 1
            return
        }
        if let groupId = userInfo["groupId"] as? String, !groupId.isEmpty {
            tappedChatEmail = nil
            tappedGroupId = groupId
            return
        }
        guard let email = userInfo["senderEmail"] as? String, !email.isEmpty else {
            logger.error("Notification is missing senderEmail; cannot open chat")
            return
        }
        tappedGroupId = nil
        tappedChatEmail = email
    }

    func clearTappedChatEmail() {
        tappedChatEmail = nil
    }

    func clearTappedGroupId() {
        tappedGroupId = nil
    }

    func handleForegroundMessage(_ message: MessageDto) {
        guard message.silent != true, message.notificationsMuted != true else { return }
        if let currentUserId {
            refreshUnreadBadge(userId: currentUserId)
        }
        if let groupId = message.groupId {
            guard let currentUserId,
                  message.senderId != currentUserId,
                  groupId != MessageSocket.shared.activeGroupId else { return }
            let content = UNMutableNotificationContent()
            content.title = message.groupName ?? "グループ"
            content.body = "\(message.senderDisplayName ?? message.senderEmail ?? "相手"): \(message.content)"
            content.sound = .default
            content.userInfo = ["messageId": message.id, "groupId": groupId]
            let request = UNNotificationRequest(
                identifier: "group-message-\(groupId)-\(message.id)",
                content: content,
                trigger: nil)
            UNUserNotificationCenter.current().add(request) { [logger] error in
                if let error {
                    logger.error("Foreground group message notification failed: \(error.localizedDescription, privacy: .public)")
                }
            }
            return
        }
        guard let currentUserId,
              message.receiverId == currentUserId,
              let senderEmail = message.senderEmail,
              !senderEmail.isEmpty,
              activeConversationDoesNotContain(senderEmail) else {
            return
        }

        let content = UNMutableNotificationContent()
        let isUnclassified = message.unclassifiedForReceiver ?? false
        content.title = message.notificationTitle
            ?? (isUnclassified ? "未分類" : (message.senderDisplayName ?? senderEmail))
        content.body = message.notificationBody
            ?? (isUnclassified ? "未分類に新しいメッセージがあります。" : message.content)
        content.sound = .default
        content.userInfo = [
            "messageId": message.id,
            "senderEmail": senderEmail,
            "unclassified": isUnclassified
        ]
        let request = UNNotificationRequest(
            identifier: "message-\(message.id)",
            content: content,
            trigger: nil)
        UNUserNotificationCenter.current().add(request) { [logger] error in
            if let error {
                logger.error("Foreground message notification failed: \(error.localizedDescription, privacy: .public)")
            }
        }
    }

    func refreshUnreadBadge(userId: String) {
        Task {
            do {
                let unreadCount = try await APIClient.shared.fetchUnreadMessageCount(userId: userId)
                setAppBadgeCount(unreadCount)
            } catch {
                logger.error("Unread badge refresh failed: \(error.localizedDescription, privacy: .public)")
            }
        }
    }

    private func setAppBadgeCount(_ count: Int) {
        UNUserNotificationCenter.current().setBadgeCount(max(0, count)) { [logger] error in
            if let error {
                logger.error("App icon badge update failed: \(error.localizedDescription, privacy: .public)")
            }
        }
    }

    func clearMessageNotifications(messageIds: [Int64]) {
        guard !messageIds.isEmpty else { return }
        Task {
            let center = UNUserNotificationCenter.current()
            let delivered = await center.deliveredNotifications()
            let identifiers = delivered.compactMap { notification -> String? in
                guard let messageId = notification.request.content.userInfo["messageId"] as? NSNumber,
                      messageIds.contains(messageId.int64Value) else { return nil }
                return notification.request.identifier
            }
            center.removeDeliveredNotifications(withIdentifiers: identifiers)
            center.removePendingNotificationRequests(withIdentifiers: messageIds.map { "message-\($0)" })
        }
    }

    private func activeConversationDoesNotContain(_ senderEmail: String) -> Bool {
        MessageSocket.shared.activeConversationEmail?.caseInsensitiveCompare(senderEmail) != .orderedSame
    }

    private func syncDeviceToken(for userId: String) {
        guard let deviceToken = UserDefaults.standard.string(forKey: tokenKey) else { return }
        Task {
            do {
                try await APIClient.shared.registerAPNsToken(userId: userId, deviceToken: deviceToken)
                logger.info("APNs device token synced with server for user \(userId)")
            } catch {
                logger.error("APNs token registration failed: \(error.localizedDescription, privacy: .public)")
            }
        }
    }

    private func syncVoipToken(for userId: String) {
        guard let deviceToken = UserDefaults.standard.string(forKey: voipTokenKey),
              let sessionToken = AppSession.shared.sessionToken else { return }
        Task {
            do {
                try await APIClient.shared.registerVoipToken(
                    sessionToken: sessionToken,
                    deviceToken: deviceToken)
                logger.info("VoIP token synced with server for user \(userId)")
            } catch {
                logger.error("VoIP token registration failed: \(error.localizedDescription, privacy: .public)")
            }
        }
    }
}

@MainActor
final class AppDelegate: NSObject, UIApplicationDelegate, UNUserNotificationCenterDelegate, PKPushRegistryDelegate {
    private let logger = Logger(subsystem: Bundle.main.bundleIdentifier ?? "ReMe", category: "push")
    private var voipRegistry: PKPushRegistry?

    func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]? = nil
    ) -> Bool {
        UNUserNotificationCenter.current().delegate = self
        let registry = PKPushRegistry(queue: .main)
        registry.delegate = self
        registry.desiredPushTypes = [.voIP]
        voipRegistry = registry
        return true
    }

    func application(_ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken deviceToken: Data) {
        let token = deviceToken.map { String(format: "%02x", $0) }.joined()
        PushNotificationManager.shared.didRegister(deviceToken: token)
    }

    func application(_ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error) {
        logger.error("APNs remote registration failed: \(error.localizedDescription, privacy: .public)")
    }

    func pushRegistry(
        _ registry: PKPushRegistry,
        didUpdate pushCredentials: PKPushCredentials,
        for type: PKPushType
    ) {
        guard type == .voIP else { return }
        let token = pushCredentials.token.map { String(format: "%02x", $0) }.joined()
        PushNotificationManager.shared.didRegisterVoipToken(token)
    }

    func pushRegistry(
        _ registry: PKPushRegistry,
        didInvalidatePushTokenFor type: PKPushType
    ) {
        guard type == .voIP else { return }
        PushNotificationManager.shared.didInvalidateVoipToken()
    }

    func pushRegistry(
        _ registry: PKPushRegistry,
        didReceiveIncomingPushWith payload: PKPushPayload,
        for type: PKPushType,
        completion: @escaping () -> Void
    ) {
        guard type == .voIP else {
            completion()
            return
        }
        PushNotificationManager.shared.receivedIncomingCallPush(
            payload.dictionaryPayload,
            completion: completion)
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        willPresent notification: UNNotification
    ) async -> UNNotificationPresentationOptions {
        if notification.request.identifier.hasPrefix("message-") {
            return [.banner, .sound, .badge]
        }
        return []
    }

    func userNotificationCenter(
        _ center: UNUserNotificationCenter,
        didReceive response: UNNotificationResponse
    ) async {
        PushNotificationManager.shared.openChatFromNotification(
            userInfo: response.notification.request.content.userInfo)
    }
}
