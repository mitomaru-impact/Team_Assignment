import CoreImage.CIFilterBuiltins
import SwiftUI
import UIKit
import Vision
import VisionKit

enum FriendQRPayload {
    static func value(for publicUserId: String) -> String {
        "reme://friend/\(publicUserId)"
    }

    static func publicUserId(from value: String) -> String? {
        guard let components = URLComponents(string: value),
              components.scheme?.lowercased() == "reme",
              components.host?.lowercased() == "friend",
              let candidate = components.path.split(separator: "/").last,
              let uuid = UUID(uuidString: String(candidate)) else {
            return nil
        }
        return uuid.uuidString.lowercased()
    }
}

struct FriendQRCodeView: View {
    let publicUserId: String
    let displayName: String

    private var qrCode: UIImage? {
        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(FriendQRPayload.value(for: publicUserId).utf8)
        filter.correctionLevel = "M"
        guard let outputImage = filter.outputImage else {
            return nil
        }
        let scaledImage = outputImage.transformed(by: CGAffineTransform(scaleX: 12, y: 12))
        guard let cgImage = CIContext().createCGImage(scaledImage, from: scaledImage.extent) else {
            return nil
        }
        return UIImage(cgImage: cgImage)
    }

    var body: some View {
        VStack(spacing: 20) {
            Text(displayName)
                .font(.title2.weight(.semibold))
            if let qrCode {
                Image(uiImage: qrCode)
                    .interpolation(.none)
                    .resizable()
                    .scaledToFit()
                    .padding(20)
                    .background(.white, in: RoundedRectangle(cornerRadius: 20))
                    .padding(.horizontal, 32)
                    .accessibilityLabel("友だち追加用QRコード")
            } else {
                ContentUnavailableView("QRコードを作成できませんでした", systemImage: "qrcode")
            }
            Text("このQRコードを相手に読み取ってもらうと、友だちに追加できます。")
                .font(.subheadline)
                .foregroundStyle(.secondary)
                .multilineTextAlignment(.center)
                .padding(.horizontal, 32)
            Spacer(minLength: 0)
        }
        .padding(.top, 32)
        .navigationTitle("自分のQRコード")
        .navigationBarTitleDisplayMode(.inline)
    }
}

struct FriendQRScannerView: View {
    let onScan: (String) -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var scanError: String?

    var body: some View {
        Group {
            if DataScannerViewController.isSupported && DataScannerViewController.isAvailable {
                FriendQRDataScanner(onScan: onScan) { error in
                    scanError = error
                }
                .ignoresSafeArea(edges: .bottom)
            } else {
                ContentUnavailableView(
                    "カメラを利用できません",
                    systemImage: "camera",
                    description: Text("設定アプリでre-meのカメラへのアクセスを許可してください。"))
            }
        }
        .navigationTitle("QRコードを読み取る")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button("閉じる") { dismiss() }
            }
        }
        .alert("QRコードを読み取れません", isPresented: Binding(
            get: { scanError != nil },
            set: { if !$0 { scanError = nil } }
        )) {
            Button("OK", role: .cancel) { scanError = nil }
        } message: {
            Text(scanError ?? "")
        }
    }
}

private struct FriendQRDataScanner: UIViewControllerRepresentable {
    let onScan: (String) -> Void
    let onError: (String) -> Void

    func makeCoordinator() -> Coordinator {
        Coordinator(onScan: onScan, onError: onError)
    }

    func makeUIViewController(context: Context) -> DataScannerViewController {
        let scanner = DataScannerViewController(
            recognizedDataTypes: [.barcode(symbologies: [.qr])],
            qualityLevel: .accurate,
            isHighlightingEnabled: true)
        scanner.delegate = context.coordinator
        do {
            try scanner.startScanning()
        } catch {
            context.coordinator.onError(error.localizedDescription)
        }
        return scanner
    }

    func updateUIViewController(_ uiViewController: DataScannerViewController, context: Context) {}

    final class Coordinator: NSObject, DataScannerViewControllerDelegate {
        let onScan: (String) -> Void
        let onError: (String) -> Void
        private var didScan = false

        init(onScan: @escaping (String) -> Void, onError: @escaping (String) -> Void) {
            self.onScan = onScan
            self.onError = onError
        }

        func dataScanner(
            _ dataScanner: DataScannerViewController,
            didAdd addedItems: [RecognizedItem],
            allItems: [RecognizedItem]
        ) {
            guard !didScan else { return }
            for item in addedItems {
                guard case .barcode(let barcode) = item,
                      let value = barcode.payloadStringValue else { continue }
                didScan = true
                onScan(value)
                return
            }
        }
    }
}
