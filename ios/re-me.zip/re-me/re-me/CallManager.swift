import AVFAudio
import Combine
import Foundation
import SwiftUI
@preconcurrency import WebRTC

struct CallScreenModel: Identifiable {
    let id: String
    let peerName: String
    let phase: Phase

    enum Phase: Equatable {
        case incoming
        case outgoing
        case active
    }
}

@MainActor
final class CallManager: ObservableObject {
    static let shared = CallManager()

    @Published private(set) var callScreen: CallScreenModel?
    @Published private(set) var callErrorMessage: String?
    @Published private(set) var isMuted = false
    @Published private(set) var isSpeakerEnabled = true
    @Published private(set) var isMinimized = false
    @Published private(set) var isStartingCall = false
    @Published private(set) var isConnecting = false

    private var currentCallId: String?
    private var currentPeerName = "通話"
    private var peerConnection: P2PCallConnection?
    private var ringTimeoutTask: Task<Void, Never>?
    private var connectionTimeoutTask: Task<Void, Never>?
    private var hasRemoteDescription = false
    private var canSendLocalCandidates = false
    private var pendingRemoteCandidates: [RTCIceCandidate] = []
    private var pendingLocalCandidates: [RTCIceCandidate] = []

    private init() {}

    func handle(_ event: MessageSocket.CallSignalingEvent) {
        guard let callId = event.callId else {
            if event.type == "call_signal_error" {
                callErrorMessage = event.message ?? "通話シグナリングに失敗しました"
                Task { await finish(notifyServer: true) }
            }
            return
        }

        switch event.type {
        case "incoming_call":
            receiveIncomingCall(
                callId: callId,
                callerEmail: event.callerEmail ?? "不明な相手",
                callerName: event.callerName ?? event.callerEmail ?? "不明な相手")
        case "call_accepted":
            guard currentCallId == callId else { return }
            ringTimeoutTask?.cancel()
            ringTimeoutTask = nil
            isConnecting = true
            scheduleConnectionTimeout(for: callId)
            CallKitCoordinator.shared.reportConnecting(callId: callId)
            if let peerName = event.peerName {
                callScreen = CallScreenModel(id: callId, peerName: peerName, phase: .outgoing)
            }
            Task { await startCallerPeerConnection(callId: callId) }
        case "call_offer":
            guard currentCallId == callId, let sdp = event.sdp else { return }
            Task { await receiveOffer(sdp, callId: callId) }
        case "call_answer":
            guard currentCallId == callId, let sdp = event.sdp else { return }
            Task { await receiveAnswer(sdp, callId: callId) }
        case "ice_candidate":
            guard currentCallId == callId,
                  let sdp = event.candidate,
                  let lineIndex = event.sdpMLineIndex else { return }
            let candidate = RTCIceCandidate(
                sdp: sdp,
                sdpMLineIndex: Int32(lineIndex),
                sdpMid: event.sdpMid)
            Task { await receiveCandidate(candidate, callId: callId) }
        case "call_declined", "call_ended":
            guard currentCallId == callId else { return }
            Task { await finish(notifyServer: false) }
        case "call_signal_error":
            guard currentCallId == callId else { return }
            callErrorMessage = event.message ?? "通話シグナリングに失敗しました"
            Task { await finish(notifyServer: true) }
        default:
            break
        }
    }

    func receiveIncomingCall(
        callId: String,
        callerEmail: String,
        callerName: String,
        completion: @escaping () -> Void = {}
    ) {
        if currentCallId == callId {
            completion()
            return
        }
        guard currentCallId == nil else {
            completion()
            if let sessionToken = AppSession.shared.sessionToken {
                Task {
                    do {
                        try await APIClient.shared.declineCall(sessionToken: sessionToken, callId: callId)
                    } catch {
                        NSLog("Failed to decline an incoming call while another call is active: %@", error.localizedDescription)
                    }
                }
            }
            return
        }
        currentCallId = callId
        currentPeerName = callerName
        scheduleRingTimeout(for: callId)
        CallKitCoordinator.shared.reportIncomingCall(
            callId: callId,
            callerName: callerName,
            callerEmail: callerEmail,
            completion: completion)
    }

    func startCall(targetEmail: String, peerName: String) async {
        guard let sessionToken = AppSession.shared.sessionToken else {
            callErrorMessage = "セッションの有効期限が切れました。再ログインしてください。"
            return
        }
        guard currentCallId == nil, !isStartingCall else { return }

        isStartingCall = true
        defer { isStartingCall = false }
        let invitation: CallInvitationResponse
        do {
            _ = try await MessageSocket.shared.waitUntilConnected()
            invitation = try await APIClient.shared.startCall(
                sessionToken: sessionToken,
                targetEmail: targetEmail)
        } catch {
            callErrorMessage = error.localizedDescription
            return
        }

        callErrorMessage = nil
        beginOutgoingCall(
            callId: invitation.callId,
            peerName: peerName,
            peerEmail: targetEmail)
        do {
            try await CallKitCoordinator.shared.startOutgoingCall(
                callId: invitation.callId,
                peerName: peerName,
                peerEmail: targetEmail)
        } catch {
            let callKitError = error as NSError
            if callKitError.domain == "com.apple.CallKit.error.requesttransaction",
               callKitError.code == 1 {
                callErrorMessage = "CallKitを開始できませんでした。Info.plistのUIBackgroundModesにvoipが含まれているか、TestFlightに配布したアプリにも反映されているか確認してください。アプリ内で呼び出しを続けます。"
            } else {
                callErrorMessage = "CallKitを開始できませんでした。アプリ内で呼び出しを続けます: \(error.localizedDescription)"
            }
            NSLog("Could not start an outgoing CallKit call; keeping the in-app call active: %@",
                  error.localizedDescription)
        }
    }

    func beginOutgoingCall(callId: String, peerName: String, peerEmail: String) {
        guard currentCallId == nil || currentCallId == callId else { return }
        currentCallId = callId
        currentPeerName = peerName
        callScreen = CallScreenModel(id: callId, peerName: peerName, phase: .outgoing)
        scheduleRingTimeout(for: callId)
    }

    func answerIncomingCall() async throws {
        guard let callId = currentCallId,
              let sessionToken = AppSession.shared.sessionToken else {
            throw callManagerError("ログイン状態を確認できません。再ログインしてください。")
        }
        ringTimeoutTask?.cancel()
        ringTimeoutTask = nil
        isConnecting = true
        do {
            _ = try await MessageSocket.shared.waitUntilConnected()
            guard currentCallId == callId else {
                throw CancellationError()
            }
            try await preparePeerConnection()
            guard currentCallId == callId else {
                throw CancellationError()
            }
            _ = try await APIClient.shared.acceptCall(sessionToken: sessionToken, callId: callId)
            guard currentCallId == callId else { return }
            scheduleConnectionTimeout(for: callId)
        } catch {
            if currentCallId == callId {
                callErrorMessage = error.localizedDescription
                await finish(notifyServer: true)
            }
            throw error
        }
    }

    func answerIncomingCallFromUI() async {
        guard let callId = currentCallId else { return }
        isConnecting = true
        do {
            try await CallKitCoordinator.shared.requestAnswerCall(callId: callId)
        } catch {
            if currentCallId == callId {
                isConnecting = false
                callErrorMessage = error.localizedDescription
            }
        }
    }

    func declineIncomingCall() {
        guard let callId = currentCallId else { return }
        Task {
            do {
                try await CallKitCoordinator.shared.requestEndCall(callId: callId)
            } catch {
                if currentCallId == callId {
                    await finish(notifyServer: true)
                    callErrorMessage = error.localizedDescription
                }
            }
        }
    }

    func endCall() {
        guard let callId = currentCallId else { return }
        Task {
            do {
                try await CallKitCoordinator.shared.requestEndCall(callId: callId)
            } catch {
                if currentCallId == callId {
                    await finish(notifyServer: true)
                    callErrorMessage = error.localizedDescription
                }
            }
        }
    }

    func endCallAndWait(sessionToken: String?) async {
        await finish(notifyServer: true, sessionToken: sessionToken)
    }

    func toggleMute() {
        guard let callId = currentCallId else { return }
        let newValue = !isMuted
        Task {
            do {
                try await CallKitCoordinator.shared.requestMute(callId: callId, muted: newValue)
            } catch {
                setMuted(newValue)
                NSLog("Failed to synchronize mute state with CallKit: %@", error.localizedDescription)
            }
        }
    }

    func setMuted(_ muted: Bool) {
        isMuted = muted
        peerConnection?.setMuted(muted)
    }

    func toggleSpeaker() {
        setSpeakerEnabled(!isSpeakerEnabled)
    }

    func setSpeakerEnabled(_ enabled: Bool) {
        let audioSession = AVAudioSession.sharedInstance()
        do {
            try audioSession.overrideOutputAudioPort(enabled ? .speaker : .none)
            isSpeakerEnabled = enabled
        } catch {
            callErrorMessage = "スピーカーを切り替えられませんでした: \(error.localizedDescription)"
        }
    }

    func minimizeCall() {
        guard callScreen?.phase == .active else { return }
        isMinimized = true
    }

    func restoreCall() {
        isMinimized = false
    }

    func endFromCallKit() async {
        guard let callId = currentCallId else { return }
        let token = AppSession.shared.sessionToken
        if let token {
            do {
                try await APIClient.shared.endCall(sessionToken: token, callId: callId)
            } catch {
                NSLog("Failed to end the call from CallKit: %@", error.localizedDescription)
            }
        }
        await finish(notifyServer: false, reportCallKit: false)
    }

    func rejectIncomingCallAfterCallKitFailure(callId: String) async {
        guard currentCallId == callId else { return }
        if let token = AppSession.shared.sessionToken {
            do {
                try await APIClient.shared.declineCall(sessionToken: token, callId: callId)
            } catch {
                NSLog("Failed to decline a call that CallKit could not report: %@", error.localizedDescription)
            }
        }
        await finish(notifyServer: false, reportCallKit: false)
    }

    func finishAfterCallKitReset(callId: String) async {
        guard currentCallId == callId else { return }
        await finish(notifyServer: true, reportCallKit: false)
    }

    func dismissCallScreen() {
        endCall()
    }

    func dismissError() {
        callErrorMessage = nil
    }

    private func startCallerPeerConnection(callId: String) async {
        do {
            try await preparePeerConnection()
            guard currentCallId == callId, let peerConnection else { return }
            let sdp = try await peerConnection.createOffer()
            try await sendSignal(type: "call_offer", callId: callId, sdp: sdp)
            canSendLocalCandidates = true
            await flushLocalCandidates(for: callId)
        } catch {
            await failCall("通話接続を開始できませんでした: \(error.localizedDescription)")
        }
    }

    private func receiveOffer(_ sdp: String, callId: String) async {
        do {
            guard currentCallId == callId, let peerConnection else { return }
            let answer = try await peerConnection.applyOfferAndCreateAnswer(sdp)
            hasRemoteDescription = true
            await flushRemoteCandidates()
            try await sendSignal(type: "call_answer", callId: callId, sdp: answer)
            canSendLocalCandidates = true
            await flushLocalCandidates(for: callId)
        } catch {
            await failCall("通話応答を処理できませんでした: \(error.localizedDescription)")
        }
    }

    private func receiveAnswer(_ sdp: String, callId: String) async {
        do {
            guard currentCallId == callId, let peerConnection else { return }
            try await peerConnection.applyAnswer(sdp)
            hasRemoteDescription = true
            await flushRemoteCandidates()
        } catch {
            await failCall("通話応答を処理できませんでした: \(error.localizedDescription)")
        }
    }

    private func receiveCandidate(_ candidate: RTCIceCandidate, callId: String) async {
        guard currentCallId == callId else { return }
        guard hasRemoteDescription, let peerConnection else {
            pendingRemoteCandidates.append(candidate)
            return
        }
        do {
            try await peerConnection.addRemoteCandidate(candidate)
        } catch {
            await failCall("ネットワーク接続情報を処理できませんでした: \(error.localizedDescription)")
        }
    }

    private func preparePeerConnection() async throws {
        try await requestMicrophonePermission()
        guard peerConnection == nil else { return }
        let connection = try P2PCallConnection.create()
        connection.onLocalCandidate = { [weak self] candidate in
            Task { @MainActor [weak self] in
                self?.handleLocalCandidate(candidate)
            }
        }
        connection.onConnectionStateChanged = { [weak self] state in
            Task { @MainActor [weak self] in
                self?.handleConnectionState(state)
            }
        }
        peerConnection = connection
        connection.setMuted(isMuted)
        hasRemoteDescription = false
        canSendLocalCandidates = false
        pendingRemoteCandidates = []
        pendingLocalCandidates = []
    }

    private func requestMicrophonePermission() async throws {
        let audioSession = AVAudioSession.sharedInstance()
        switch audioSession.recordPermission {
        case .granted:
            return
        case .denied:
            throw NSError(
                domain: "P2PCallConnection",
                code: 3,
                userInfo: [NSLocalizedDescriptionKey: "設定アプリでマイクへのアクセスを許可してください"])
        case .undetermined:
            let granted = await withCheckedContinuation { continuation in
                audioSession.requestRecordPermission { continuation.resume(returning: $0) }
            }
            guard granted else {
                throw NSError(
                    domain: "P2PCallConnection",
                    code: 3,
                    userInfo: [NSLocalizedDescriptionKey: "マイクへのアクセスが許可されませんでした"])
            }
        @unknown default:
            throw NSError(
                domain: "P2PCallConnection",
                code: 3,
                userInfo: [NSLocalizedDescriptionKey: "マイクのアクセス状態を確認できませんでした"])
        }
    }

    private func handleLocalCandidate(_ candidate: RTCIceCandidate) {
        guard canSendLocalCandidates, let callId = currentCallId else {
            pendingLocalCandidates.append(candidate)
            return
        }
        Task { await sendCandidate(candidate, callId: callId) }
    }

    private func flushLocalCandidates(for callId: String) async {
        let candidates = pendingLocalCandidates
        pendingLocalCandidates.removeAll()
        for candidate in candidates {
            guard currentCallId == callId else { return }
            await sendCandidate(candidate, callId: callId)
        }
    }

    private func flushRemoteCandidates() async {
        let candidates = pendingRemoteCandidates
        pendingRemoteCandidates.removeAll()
        guard let peerConnection else { return }
        for candidate in candidates {
            do {
                try await peerConnection.addRemoteCandidate(candidate)
            } catch {
                await failCall("ネットワーク接続情報を処理できませんでした: \(error.localizedDescription)")
                return
            }
        }
    }

    private func sendCandidate(_ candidate: RTCIceCandidate, callId: String) async {
        do {
            try await MessageSocket.shared.sendCallSignal(.init(
                type: "ice_candidate",
                callId: callId,
                candidate: candidate.sdp,
                sdpMid: candidate.sdpMid,
                sdpMLineIndex: Int(candidate.sdpMLineIndex)))
        } catch {
            await failCall("通話のネットワーク情報を送信できませんでした: \(error.localizedDescription)")
        }
    }

    private func sendSignal(type: String, callId: String, sdp: String) async throws {
        try await MessageSocket.shared.sendCallSignal(.init(type: type, callId: callId, sdp: sdp))
    }

    private func handleConnectionState(_ state: RTCIceConnectionState) {
        switch state {
        case .connected, .completed:
            guard let callId = currentCallId else { return }
            isConnecting = false
            self.callScreen = CallScreenModel(id: callId, peerName: currentPeerName, phase: .active)
            CallKitCoordinator.shared.reportConnected(callId: callId)
            ringTimeoutTask?.cancel()
            ringTimeoutTask = nil
            connectionTimeoutTask?.cancel()
            connectionTimeoutTask = nil
        case .failed:
            Task { await failCall("相手との直接接続に失敗しました。このネットワークでは通話できない可能性があります。") }
        default:
            break
        }
    }

    private func failCall(_ message: String) async {
        callErrorMessage = message
        await finish(notifyServer: true)
    }

    private func finish(
        notifyServer: Bool,
        sessionToken explicitSessionToken: String? = nil,
        reportCallKit: Bool = true
    ) async {
        let sessionToken = explicitSessionToken ?? AppSession.shared.sessionToken
        ringTimeoutTask?.cancel()
        ringTimeoutTask = nil
        connectionTimeoutTask?.cancel()
        connectionTimeoutTask = nil
        let callId = currentCallId
        currentCallId = nil
        currentPeerName = "通話"
        if reportCallKit, let callId {
            CallKitCoordinator.shared.reportEnded(callId: callId)
        }
        let oldConnection = peerConnection
        peerConnection = nil
        oldConnection?.close()
        callScreen = nil
        isMuted = false
        isSpeakerEnabled = true
        isMinimized = false
        isConnecting = false
        hasRemoteDescription = false
        canSendLocalCandidates = false
        pendingRemoteCandidates.removeAll()
        pendingLocalCandidates.removeAll()

        if notifyServer, let callId, let sessionToken {
            do {
                try await APIClient.shared.endCall(sessionToken: sessionToken, callId: callId)
            } catch {
                NSLog("Failed to notify the server that the call ended: %@", error.localizedDescription)
            }
        }
    }

    private func callManagerError(_ message: String) -> NSError {
        NSError(domain: "CallManager", code: 1, userInfo: [NSLocalizedDescriptionKey: message])
    }

    private func scheduleRingTimeout(for callId: String) {
        ringTimeoutTask?.cancel()
        ringTimeoutTask = Task {
            try? await Task.sleep(for: .seconds(45))
            guard !Task.isCancelled, currentCallId == callId else { return }
            callErrorMessage = "通話への応答がありませんでした。"
            await finish(notifyServer: true)
        }
    }

    private func scheduleConnectionTimeout(for callId: String) {
        connectionTimeoutTask?.cancel()
        connectionTimeoutTask = Task {
            try? await Task.sleep(for: .seconds(30))
            guard !Task.isCancelled, currentCallId == callId, isConnecting else { return }
            await failCall(
                "相手との直接接続ができませんでした。両方のアプリが通話画面を開いたままか確認してください。ネットワークによってはTURNサーバーが必要です。")
        }
    }
}

struct CallScreen: View {
    @ObservedObject private var callManager = CallManager.shared

    var body: some View {
        VStack(spacing: 28) {
            HStack {
                Spacer()
                if callManager.callScreen?.phase == .active {
                    Button {
                        callManager.minimizeCall()
                    } label: {
                        Image(systemName: "minus")
                            .font(.headline)
                            .frame(width: 36, height: 36)
                    }
                    .accessibilityLabel("通話画面を最小化")
                }
            }
            Spacer()
            Image(systemName: callManager.callScreen?.phase == .active
                  ? "waveform"
                  : "phone.fill")
                .font(.system(size: 42, weight: .medium))
                .foregroundStyle(.tint)
                .frame(width: 104, height: 104)
                .background(.tint.opacity(0.12), in: Circle())
            VStack(spacing: 8) {
                Text(callManager.callScreen?.peerName ?? "通話")
                    .font(.title2.weight(.semibold))
                Text(statusText)
                    .foregroundStyle(.secondary)
            }
            if let errorMessage = callManager.callErrorMessage {
                Text(errorMessage)
                    .font(.footnote)
                    .foregroundStyle(.red)
                    .multilineTextAlignment(.center)
                    .accessibilityIdentifier("callErrorMessage")
            }
            Spacer()

            HStack(spacing: 36) {
                if callManager.callScreen?.phase == .active {
                    callButton(
                        callManager.isMuted ? "ミュート解除" : "ミュート",
                        symbol: callManager.isMuted ? "mic.slash.fill" : "mic.fill",
                        color: .gray
                    ) {
                        callManager.toggleMute()
                    }
                    callButton(
                        callManager.isSpeakerEnabled ? "スピーカー" : "受話口",
                        symbol: callManager.isSpeakerEnabled ? "speaker.wave.2.fill" : "phone",
                        color: .gray
                    ) {
                        callManager.toggleSpeaker()
                    }
                    callButton("終了", symbol: "phone.down.fill", color: .red) {
                        callManager.endCall()
                    }
                } else {
                    callButton("キャンセル", symbol: "phone.down.fill", color: .red) {
                        callManager.endCall()
                    }
                    .disabled(callManager.isStartingCall)
                }
            }
            .padding(.bottom, 36)
        }
        .padding(24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color(.systemGroupedBackground))
    }

    private var statusText: String {
        if callManager.isConnecting { return "接続中…" }
        switch callManager.callScreen?.phase {
        case .incoming: return "着信中"
        case .outgoing: return "呼び出し中…"
        case .active: return "通話中"
        case .none: return ""
        }
    }

    private func callButton(
        _ title: String,
        symbol: String,
        color: Color,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            VStack(spacing: 10) {
                Image(systemName: symbol)
                    .font(.title2)
                    .foregroundStyle(.white)
                    .frame(width: 64, height: 64)
                    .background(color, in: Circle())
                Text(title)
                    .font(.caption)
                    .foregroundStyle(.primary)
            }
        }
        .buttonStyle(.plain)
    }
}
