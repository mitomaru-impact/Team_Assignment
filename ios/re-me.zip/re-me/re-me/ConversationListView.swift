import SwiftUI
import LocalAuthentication

private enum ConversationListAlert: String, Identifiable {
    case newProfile
    case addContact
    case newChat
    case deleteProfile
    case editProfileIdentity

    var id: String { rawValue }

    var title: String {
        switch self {
        case .newProfile: return "プロファイルを追加"
        case .addContact: return "相手をこのプロファイルに追加"
        case .newChat: return "新規チャット"
        case .deleteProfile: return "プロファイルを削除"
        case .editProfileIdentity: return "プロファイルの表示名を編集"
        }
    }
}

private enum FriendQRSheet: String, Identifiable {
    case myCode
    case scanner

    var id: String { rawValue }
}

private enum ConversationListConfirmation {
    case assign
    case move
    case delete
    case lock
    case unlock
}

struct ConversationListView: View {
    @ObservedObject private var session = AppSession.shared
    @ObservedObject private var messageSocket = MessageSocket.shared
    @ObservedObject private var pushNotifications = PushNotificationManager.shared
    @State private var profiles: [ChatProfileDto] = []
    @State private var selectedProfileId: Int64?
    @State private var conversations: [ConversationDto] = []
    @State private var groupConversations: [GroupConversationDto] = []
    @State private var conversationMuteModes: [String: String] = [:]
    @State private var pendingMuteEmail: String?
    @State private var pendingMuteGroupId: String?
    @State private var showingMuteOptions = false
    @State private var unclassifiedConversations: [ConversationDto] = []
    @State private var showingUnclassified = false
    @State private var activeAlert: ConversationListAlert?
    @State private var newTargetEmail = ""
    @State private var newProfileName = ""
    @State private var profileDisplayName = ""
    @State private var contactEmail = ""
    @State private var pendingAssignment: ConversationDto?
    @State private var conversationToMove: ConversationDto?
    @State private var conversationToDelete: ConversationDto?
    @State private var activeConfirmation: ConversationListConfirmation?
    @State private var pendingLockKey: String?
    @State private var activeChatEmail: String? = nil
    @State private var activeChatGroupId: String?
    @State private var activeChatTargetName: String?
    @State private var isNavigateToChat = false
    @State private var lockedConversationKeys = Set(
        UserDefaults.standard.stringArray(forKey: "lockedConversationKeys") ?? [])
    @State private var loadGeneration = 0
    @State private var isLoading = false
    @State private var errorMessage: String?
    @State private var searchText = ""
    @State private var activeFriendQRSheet: FriendQRSheet?
    @State private var showingGroupCreation = false
    @State private var handledUnclassifiedNotificationRevision = 0

    var body: some View {
        List {
            Section {
                Menu {
                    ForEach(profiles) { profile in
                        Button {
                            showingUnclassified = false
                            selectedProfileId = profile.id
                            Task { await loadConversations() }
                        } label: {
                            if !showingUnclassified && selectedProfileId == profile.id {
                                Label("\(profile.name) — \(profile.displayName)", systemImage: "checkmark")
                            } else {
                                Text("\(profile.name) — \(profile.displayName)")
                            }
                        }
                    }

                    Divider()
                    Button {
                        showingUnclassified = true
                        Task { await loadConversations() }
                    } label: {
                        if showingUnclassified {
                            Label("未分類", systemImage: "checkmark")
                        } else {
                            Text("未分類")
                        }
                    }
                    if profiles.first(where: { $0.id == selectedProfileId })?.defaultProfile == false {
                        Divider()
                        Button("このプロファイルを削除", systemImage: "trash", role: .destructive) {
                            activeAlert = .deleteProfile
                        }
                    }
                }
                label: {
                    HStack(spacing: 8) {
                        Image(systemName: showingUnclassified ? "tray" : "person.2")
                            .foregroundStyle(.tint)
                        Text(showingUnclassified ? "未分類" : selectedProfileName)
                            .font(.headline)
                            .foregroundStyle(.primary)
                        if !showingUnclassified, let selectedProfile {
                            Text(selectedProfile.displayName)
                                .font(.subheadline)
                                .foregroundStyle(.secondary)
                        }
                        if showingUnclassified && unclassifiedUnreadCount > 0 {
                            Text(unclassifiedUnreadCount > 99 ? "99+" : "\(unclassifiedUnreadCount)")
                                .font(.caption2.weight(.bold))
                                .foregroundStyle(.white)
                                .padding(.horizontal, 6)
                                .padding(.vertical, 3)
                                .background(.red, in: Capsule())
                        }
                        Image(systemName: "chevron.up.chevron.down")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.secondary)
                    }
                    .contentShape(Rectangle())
                }
                .accessibilityLabel("表示するプロファイル")
            }
            .listRowBackground(Color.clear)

            if let errorMessage {
                Section {
                    Label(errorMessage, systemImage: "exclamationmark.triangle")
                        .foregroundStyle(.red)
                    Button("再読み込み") {
                        Task { await loadConversations() }
                    }
                } header: {
                    Text("履歴を読み込めませんでした")
                }
            }

            if isLoading && currentConversations.isEmpty && currentGroups.isEmpty {
                Section {
                    ProgressView("履歴を読み込み中")
                }
            } else if currentConversations.isEmpty && currentGroups.isEmpty && errorMessage == nil {
                if searchText.isEmpty {
                    ContentUnavailableView(
                        showingUnclassified ? "未分類のメッセージはありません" : "やり取りはまだありません",
                        systemImage: showingUnclassified ? "tray" : "bubble.left.and.bubble.right",
                        description: Text(showingUnclassified
                                          ? "新しい相手から届いたメッセージはここに表示されます。"
                                          : "右上の＋から相手を追加して、会話を始めましょう。"))
                        .listRowBackground(Color.clear)
                        .listRowSeparator(.hidden)
                } else {
                    ContentUnavailableView.search(text: searchText)
                        .listRowBackground(Color.clear)
                        .listRowSeparator(.hidden)
                }
            } else {
                if !currentGroups.isEmpty {
                    Section("グループ") {
                        ForEach(currentGroups) { group in
                        groupConversationEntry(group)
                        .swipeActions(edge: .leading, allowsFullSwipe: false) {
                            Button {
                                requestConversationLockToggle(
                                    key: groupLockKey(group.id))
                            } label: {
                                if isConversationLocked(key: groupLockKey(group.id)) {
                                    Label("ロック解除", systemImage: "lock.open")
                                } else {
                                    Label("ロック", systemImage: "lock")
                                }
                            }
                            .tint(.indigo)
                            Button {
                                pendingMuteGroupId = group.id
                                pendingMuteEmail = nil
                                    showingMuteOptions = true
                                } label: {
                                    if conversationMuteModes["group:\(group.id)"] == nil {
                                        Label("ミュート", systemImage: "bell.slash")
                                    } else {
                                        Label("ミュート解除", systemImage: "bell")
                                    }
                                }
                                .tint(.orange)
                            }
                        }
                    }
                }
                if !currentConversations.isEmpty {
                    Section {
                        ForEach(currentConversations) { conv in
                            conversationEntry(conv)
                                .swipeActions(edge: .leading, allowsFullSwipe: false) {
                                    Button {
                                        requestConversationLockToggle(
                                            key: emailLockKey(conv.targetEmail))
                                    } label: {
                                        if isConversationLocked(key: emailLockKey(conv.targetEmail)) {
                                            Label("ロック解除", systemImage: "lock.open")
                                        } else {
                                            Label("ロック", systemImage: "lock")
                                        }
                                    }
                                    .tint(.indigo)
                                    Button {
                                        pendingMuteEmail = conv.targetEmail
                                        pendingMuteGroupId = nil
                                        showingMuteOptions = true
                                    } label: {
                                        if conversationMuteModes["email:\(conv.targetEmail.lowercased())"] == nil {
                                            Label("ミュート", systemImage: "bell.slash")
                                        } else {
                                            Label("ミュート解除", systemImage: "bell")
                                        }
                                    }
                                    .tint(.orange)
                                }
                                .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                    Button(role: .destructive) {
                                        conversationToDelete = conv
                                        activeConfirmation = .delete
                                    } label: {
                                        Label("削除", systemImage: "trash")
                                    }
                                    if showingUnclassified || profiles.count > 1 {
                                        Button {
                                            conversationToMove = conv
                                            activeConfirmation = .move
                                        } label: {
                                            Label("移動", systemImage: "folder")
                                        }
                                        .tint(.blue)
                                    }
                                }
                        }
                    }
                }
            }
        }
        .listStyle(.insetGrouped)
        .searchable(text: $searchText, prompt: "名前やメッセージ")
        .refreshable {
            await loadConversations()
        }
        .navigationTitle("メッセージ")
        .confirmationDialog(
            "通知設定",
            isPresented: $showingMuteOptions,
            titleVisibility: .visible
        ) {
            if pendingMuteIsMuted {
                Button("ミュートを解除", role: .destructive) {
                    updateMute(mode: "NONE")
                }
            } else {
                Button("メンションは通知する") {
                    updateMute(mode: "MENTIONS_ONLY")
                }
                Button("すべてのメッセージをミュート") {
                    updateMute(mode: "ALL")
                }
            }
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("選択した通知設定は、この会話にだけ適用されます。")
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Menu {
                    Button("プロファイルを追加", systemImage: "person.badge.plus") {
                        newProfileName = ""
                        activeAlert = .newProfile
                    }
                    Button("プロファイルの表示名を編集", systemImage: "person.crop.circle") {
                        guard let selectedProfile = selectedProfile else { return }
                        profileDisplayName = selectedProfile.displayName
                        activeAlert = .editProfileIdentity
                    }
                    .disabled(selectedProfile == nil)
                    Button("このプロファイルに相手を追加", systemImage: "person.crop.circle.badge.plus") {
                        contactEmail = ""
                        activeAlert = .addContact
                    }
                    Button("自分のQRコード", systemImage: "qrcode") {
                        activeFriendQRSheet = .myCode
                    }
                    Button("QRコードを読み取る", systemImage: "viewfinder") {
                        activeFriendQRSheet = .scanner
                    }
                    Button("新規チャット", systemImage: "square.and.pencil") {
                        newTargetEmail = ""
                        activeAlert = .newChat
                    }
                    Button("グループを作成", systemImage: "person.3") {
                        showingGroupCreation = true
                    }
                    .disabled(selectedProfileId == nil)
                } label: {
                    Image(systemName: "plus")
                }
                .accessibilityLabel("新規作成")
            }
        }
        .alert(
            activeAlert?.title ?? "",
            isPresented: Binding(
                get: { activeAlert != nil },
                set: { if !$0 { activeAlert = nil } }),
            presenting: activeAlert
        ) { alert in
            switch alert {
            case .newProfile:
                TextField("プロファイル名", text: $newProfileName)
                Button("キャンセル", role: .cancel) {}
                Button("追加") { createProfile() }
            case .addContact:
                TextField("相手のメールアドレス", text: $contactEmail)
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                Button("キャンセル", role: .cancel) {}
                Button("追加") { addContact() }
            case .newChat:
                TextField("相手のメールアドレス", text: $newTargetEmail)
                    .keyboardType(.emailAddress)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                Button("キャンセル", role: .cancel) {}
                Button("開始") { startNewChat() }
            case .deleteProfile:
                Button("キャンセル", role: .cancel) {}
                Button("削除", role: .destructive) { deleteSelectedProfile() }
            case .editProfileIdentity:
                TextField("相手に表示する名前", text: $profileDisplayName)
                Button("キャンセル", role: .cancel) {}
                Button("保存") { updateProfileDisplayName() }
            }
        } message: { alert in
            switch alert {
            case .newChat:
                Text("メッセージを送りたい相手のメールアドレスを入力してください")
            case .deleteProfile:
                Text("このプロファイルの連絡先は未分類に戻ります。")
            case .editProfileIdentity:
                Text("このプロファイルから送るメッセージに表示する名前です。アイコン設定は後日追加予定です。")
            default:
                Text("")
            }
        }
        .confirmationDialog(
            confirmationTitle,
            isPresented: Binding(
                get: { activeConfirmation != nil },
                set: { if !$0 { activeConfirmation = nil } }),
            titleVisibility: .visible
        ) {
            switch activeConfirmation {
            case .assign:
                ForEach(profiles) { profile in
                    Button(profile.name) { assignPendingContact(to: profile) }
                }
                Button("キャンセル", role: .cancel) {}
            case .move:
                ForEach(profiles.filter { showingUnclassified || $0.id != selectedProfileId }) { profile in
                    Button(profile.name) { moveConversation(to: profile) }
                }
                Button("キャンセル", role: .cancel) {}
            case .delete:
                Button("自分の画面から削除", role: .destructive) {
                    deleteConversation(deleteForBoth: false)
                }
                Button("双方の画面から削除", role: .destructive) {
                    deleteConversation(deleteForBoth: true)
                }
                Button("キャンセル", role: .cancel) {}
            case .lock:
                Button("ロック", role: .destructive) {
                    applyConversationLock()
                }
                Button("キャンセル", role: .cancel) {}
            case .unlock:
                Button("ロックを解除", role: .destructive) {
                    applyConversationUnlock()
                }
                Button("キャンセル", role: .cancel) {}
            case nil:
                Button("キャンセル", role: .cancel) {}
            }
        } message: {
            if activeConfirmation == .delete {
                Text("双方から削除すると、相手側のトーク履歴も削除されます。")
            } else if activeConfirmation == .lock {
                Text("このトークをロックしますか？")
            } else if activeConfirmation == .unlock {
                Text("このトークのロックを解除しますか？")
            }
        }
        .navigationDestination(isPresented: $isNavigateToChat) {
            if let groupId = activeChatGroupId {
                ChatView(
                    targetEmail: "",
                    targetName: activeChatTargetName,
                    profileId: selectedProfileId,
                    groupId: groupId)
            } else if let email = activeChatEmail {
                ChatView(
                    targetEmail: email,
                    targetName: activeChatTargetName,
                    profileId: selectedProfileId)
            }
        }
        .sheet(item: $activeFriendQRSheet) { sheet in
            NavigationStack {
                switch sheet {
                case .myCode:
                    if let userId = session.currentUserId {
                        FriendQRCodeView(
                            publicUserId: userId,
                            displayName: selectedProfile?.displayName ?? "re-me")
                    } else {
                        ContentUnavailableView("ログイン状態を確認できません", systemImage: "person.crop.circle.badge.exclamationmark")
                    }
                case .scanner:
                    FriendQRScannerView { scannedValue in
                        activeFriendQRSheet = nil
                        guard let publicUserId = FriendQRPayload.publicUserId(from: scannedValue) else {
                            errorMessage = "re-meの友だちQRコードを読み取ってください。"
                            return
                        }
                        addContact(publicUserId: publicUserId)
                    }
                }
            }
        }
        .sheet(isPresented: $showingGroupCreation) {
            if let userId = session.currentUserId, let selectedProfileId {
                GroupCreationSheet(
                    userId: userId,
                    profileId: selectedProfileId,
                    onCreated: {
                        Task { await loadConversations() }
                    })
            } else {
                ContentUnavailableView("プロファイルを読み込めません", systemImage: "person.crop.circle.badge.exclamationmark")
            }
        }
        .onAppear {
            showUnclassifiedForPendingNotification()
            Task { await loadConversations() }
        }
        .onChange(of: pushNotifications.unclassifiedNotificationRevision) { _, _ in
            showUnclassifiedForPendingNotification()
        }
        .onChange(of: messageSocket.latestMessageRevision) { _, _ in
            Task { await loadConversations() }
            Task { await loadUnclassifiedConversations() }
        }
        .onChange(of: messageSocket.messageRecallRevision) { _, _ in
            Task { await loadConversations() }
            Task { await loadUnclassifiedConversations() }
        }
        .onChange(of: messageSocket.conversationReadRevision) { _, _ in
            Task { await loadConversations() }
        }
        .onChange(of: messageSocket.conversationDeletionRevision) { _, _ in
            Task { await loadConversations() }
            Task { await loadUnclassifiedConversations() }
        }
        .onChange(of: messageSocket.profileIdentityRevision) { _, _ in
            Task { await loadConversations() }
            Task { await loadUnclassifiedConversations() }
        }
        .onChange(of: messageSocket.groupChangeRevision) { _, _ in
            Task { await loadConversations() }
        }
        .onChange(of: isNavigateToChat) { _, isNavigating in
            guard !isNavigating else { return }
            Task { await loadConversations() }
        }
    }

    private var currentConversations: [ConversationDto] {
        let source = showingUnclassified ? unclassifiedConversations : conversations
        guard !searchText.isEmpty else { return source }
        return source.filter {
            $0.targetName.localizedCaseInsensitiveContains(searchText)
                || $0.lastMessage.localizedCaseInsensitiveContains(searchText)
        }
    }

    private var currentGroups: [GroupConversationDto] {
        guard !searchText.isEmpty else { return groupConversations }
        return groupConversations.filter {
            $0.name.localizedCaseInsensitiveContains(searchText)
                || $0.lastMessage.localizedCaseInsensitiveContains(searchText)
        }
    }

    private var confirmationTitle: String {
        switch activeConfirmation {
        case .assign:
            return "「\(pendingAssignment?.targetName ?? "")」を追加するプロファイル"
        case .move:
            return "「\(conversationToMove?.targetName ?? "")」の移動先プロファイル"
        case .delete:
            return "「\(conversationToDelete?.targetName ?? "")」を削除"
        case .lock:
            return "トークをロック"
        case .unlock:
            return "トークのロックを解除"
        case nil:
            return ""
        }
    }

    private var selectedProfileName: String {
        selectedProfile?.name ?? "プロファイル"
    }

    private var selectedProfile: ChatProfileDto? {
        profiles.first(where: { $0.id == selectedProfileId })
    }

    private var unclassifiedUnreadCount: Int {
        unclassifiedConversations.reduce(0) { $0 + $1.unreadCount }
    }

    private var pendingMuteIsMuted: Bool {
        if let groupId = pendingMuteGroupId {
            return conversationMuteModes["group:\(groupId)"] != nil
        }
        if let email = pendingMuteEmail {
            return conversationMuteModes["email:\(email.lowercased())"] != nil
        }
        return false
    }

    private func showUnclassifiedForPendingNotification() {
        let revision = pushNotifications.unclassifiedNotificationRevision
        guard revision > handledUnclassifiedNotificationRevision else { return }
        handledUnclassifiedNotificationRevision = revision
        showingUnclassified = true
        Task { await loadConversations() }
    }

    @ViewBuilder
    private func conversationEntry(_ conversation: ConversationDto) -> some View {
        if showingUnclassified {
            Button {
                pendingAssignment = conversation
                activeConfirmation = .assign
            } label: {
                conversationRow(conversation)
            }
            .buttonStyle(.plain)
        } else {
            Button {
                openConversation(
                    lockKey: emailLockKey(conversation.targetEmail),
                    email: conversation.targetEmail,
                    targetName: conversation.targetName)
            } label: {
                conversationRow(conversation)
            }
            .buttonStyle(.plain)
        }
    }

    @ViewBuilder
    private func groupConversationEntry(_ group: GroupConversationDto) -> some View {
        Button {
            openConversation(
                lockKey: groupLockKey(group.id),
                groupId: group.id,
                targetName: group.name)
        } label: {
            groupConversationRow(group)
        }
        .buttonStyle(.plain)
    }

    private func emailLockKey(_ email: String) -> String {
        "email:\(email.lowercased())"
    }

    private func groupLockKey(_ groupId: String) -> String {
        "group:\(groupId)"
    }

    private func isConversationLocked(key: String) -> Bool {
        lockedConversationKeys.contains(key)
    }

    private func persistLockedConversations() {
        UserDefaults.standard.set(
            Array(lockedConversationKeys),
            forKey: "lockedConversationKeys")
    }

    private func requestConversationLockToggle(key: String) {
        pendingLockKey = key
        activeConfirmation = isConversationLocked(key: key) ? .unlock : .lock
    }

    private func applyConversationLock() {
        guard let key = pendingLockKey else { return }
        lockedConversationKeys.insert(key)
        persistLockedConversations()
        clearPendingLock()
    }

    private func applyConversationUnlock() {
        guard let key = pendingLockKey else { return }
        authenticateDevice(reason: "トークのロックを解除") {
            lockedConversationKeys.remove(key)
            persistLockedConversations()
            clearPendingLock()
        }
    }

    private func clearPendingLock() {
        pendingLockKey = nil
    }

    private func openConversation(
        lockKey: String,
        email: String? = nil,
        groupId: String? = nil,
        targetName: String? = nil) {
        let open = {
            activeChatEmail = email
            activeChatGroupId = groupId
            activeChatTargetName = targetName
            isNavigateToChat = true
        }
        if isConversationLocked(key: lockKey) {
            authenticateDevice(reason: "ロックされたトークを開く", completion: open)
        } else {
            open()
        }
    }

    private func authenticateDevice(reason: String, completion: @escaping () -> Void) {
        Task { @MainActor in
            let context = LAContext()
            context.localizedFallbackTitle = "iPhoneのパスコードを使用"
            var evaluationError: NSError?
            guard context.canEvaluatePolicy(
                .deviceOwnerAuthentication,
                error: &evaluationError) else {
                errorMessage = evaluationError?.localizedDescription
                    ?? "このiPhoneでは認証を利用できません。"
                return
            }

            do {
                try await context.evaluatePolicy(
                    .deviceOwnerAuthentication,
                    localizedReason: reason)
                completion()
            } catch let error as LAError {
                if error.code != .userCancel && error.code != .systemCancel {
                    errorMessage = error.localizedDescription
                }
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    @ViewBuilder
    private func conversationRow(_ conv: ConversationDto) -> some View {
        HStack(alignment: .center, spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color.blue.opacity(0.15))
                    .frame(width: 48, height: 48)
                Text(initials(from: conv.targetName))
                    .font(.headline)
                    .foregroundColor(.blue)
                Circle()
                    .fill(messageSocket.onlineUsers.contains(conv.targetEmail.lowercased()) ? Color.accentColor : Color.gray)
                    .frame(width: 12, height: 12)
                    .overlay(Circle().stroke(Color(.systemBackground), lineWidth: 2))
                    .offset(x: 17, y: 17)
            }

            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(conv.targetName)
                        .font(.headline)
                        .foregroundColor(.primary)
                    Spacer()
                    Text(formatDate(conv.updatedAt))
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
                Text(conv.lastMessage.isEmpty ? "メッセージを送信" : conv.lastMessage)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .lineLimit(2)
            }
            if conv.unreadCount > 0 {
                Text(conv.unreadCount > 99 ? "99+" : "\(conv.unreadCount)")
                    .font(.caption2.weight(.bold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 7)
                    .padding(.vertical, 4)
                    .background(Capsule().fill(Color.red))
                    .accessibilityLabel("\(conv.unreadCount)件の未読メッセージ")
            }
            if conversationMuteModes["email:\(conv.targetEmail.lowercased())"] != nil {
                Image(systemName: "bell.slash.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .accessibilityLabel("通知をミュート中")
            }
        }
        .padding(.vertical, 6)
        .contentShape(Rectangle())
    }

    private func groupConversationRow(_ group: GroupConversationDto) -> some View {
        HStack(alignment: .center, spacing: 12) {
            ZStack {
                Circle()
                    .fill(Color.purple.opacity(0.15))
                    .frame(width: 48, height: 48)
                Image(systemName: "person.3.fill")
                    .foregroundStyle(.purple)
            }
            VStack(alignment: .leading, spacing: 4) {
                HStack {
                    Text(group.name)
                        .font(.headline)
                        .foregroundStyle(.primary)
                    Spacer()
                    Text(formatDate(group.lastMessageTime ?? ""))
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }
                Text(group.lastMessage.isEmpty ? "メッセージを送信" : group.lastMessage)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .lineLimit(2)
            }
            if group.unreadCount > 0 {
                Text(group.unreadCount > 99 ? "99+" : "\(group.unreadCount)")
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 7)
                    .padding(.vertical, 4)
                    .background(Capsule().fill(Color.red))
            }
            if conversationMuteModes["group:\(group.id)"] != nil {
                Image(systemName: "bell.slash.fill")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .accessibilityLabel("通知をミュート中")
            }
        }
        .padding(.vertical, 6)
    }

    private func initials(from email: String) -> String {
        let name = email.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { return "?" }
        return String(name.prefix(2))
    }

    private func formatDate(_ value: String) -> String {
        guard let date = parseDate(value) else { return "-" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "ja_JP")
        if Calendar.current.isDateInToday(date) {
            formatter.dateFormat = "HH:mm"
        } else if Calendar.current.isDateInYesterday(date) {
            formatter.dateFormat = "昨日"
        } else {
            formatter.dateFormat = "M/d"
        }
        return formatter.string(from: date)
    }

    private func parseDate(_ value: String) -> Date? {
        let iso = ISO8601DateFormatter()
        iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = iso.date(from: value) { return date }

        let fallback = ISO8601DateFormatter()
        fallback.formatOptions = [.withInternetDateTime]
        if let date = fallback.date(from: value) { return date }

        let localDate = DateFormatter()
        localDate.locale = Locale(identifier: "en_US_POSIX")
        localDate.timeZone = TimeZone.current
        for format in ["yyyy-MM-dd'T'HH:mm:ss.SSSSSS", "yyyy-MM-dd'T'HH:mm:ss.SSS", "yyyy-MM-dd'T'HH:mm:ss"] {
            localDate.dateFormat = format
            if let date = localDate.date(from: value) { return date }
        }
        return nil
    }

    @MainActor
    private func loadConversations() async {
        guard let userId = session.currentUserId else {
            conversations = []
            errorMessage = "ログイン状態を確認してください。"
            return
        }
        loadGeneration += 1
        let generation = loadGeneration
        isLoading = true
        errorMessage = nil
        do {
            if profiles.isEmpty {
                profiles = try await APIClient.shared.fetchChatProfiles(userId: userId)
                selectedProfileId = profiles.first(where: \.defaultProfile)?.id ?? profiles.first?.id
                await loadUnclassifiedConversations()
            }
            guard let selectedProfileId else {
                throw NSError(domain: "", code: 0, userInfo: [
                    NSLocalizedDescriptionKey: "プロファイルを読み込めませんでした"
                ])
            }
            let fetched: [ConversationDto]
            if showingUnclassified {
                fetched = try await APIClient.shared.fetchUnclassifiedConversations(userId: userId)
                unclassifiedConversations = fetched
            } else {
                fetched = try await APIClient.shared.fetchConversations(
                    userId: userId, profileId: selectedProfileId)
            }
            guard generation == loadGeneration else { return }
            conversations = fetched
            groupConversations = try await APIClient.shared.fetchGroups(userId: userId)
            guard generation == loadGeneration else { return }
            await loadConversationMutes(userId: userId)
        } catch {
            guard generation == loadGeneration else { return }
            errorMessage = error.localizedDescription
        }
        if generation == loadGeneration { isLoading = false }
    }

    @MainActor
    private func loadUnclassifiedConversations() async {
        guard let userId = session.currentUserId else { return }
        do {
            unclassifiedConversations = try await APIClient.shared.fetchUnclassifiedConversations(userId: userId)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    @MainActor
    private func loadConversationMutes(userId: String) async {
        do {
            let mutes = try await APIClient.shared.fetchConversationMutes(userId: userId)
            conversationMuteModes = Dictionary(
                uniqueKeysWithValues: mutes.compactMap { mute in
                    if let groupId = mute.groupId { return ("group:\(groupId)", mute.mode) }
                    if let email = mute.targetEmail { return ("email:\(email.lowercased())", mute.mode) }
                    return nil
                })
        } catch {
            errorMessage = "ミュート設定を読み込めませんでした: \(error.localizedDescription)"
        }
    }

    @MainActor
    private func updateMute(mode: String) {
        guard let userId = session.currentUserId,
              pendingMuteEmail != nil || pendingMuteGroupId != nil else { return }
        let targetEmail = pendingMuteEmail
        let targetGroupId = pendingMuteGroupId
        Task {
            do {
                try await APIClient.shared.updateConversationMute(
                    userId: userId,
                    targetEmail: targetEmail,
                    groupId: targetGroupId,
                    mode: mode)
                await loadConversationMutes(userId: userId)
                pendingMuteEmail = nil
                pendingMuteGroupId = nil
            } catch {
                errorMessage = "ミュート設定を保存できませんでした: \(error.localizedDescription)"
            }
        }
    }

    private func createProfile() {
        guard let userId = session.currentUserId else { return }
        Task {
            do {
                try await APIClient.shared.createChatProfile(userId: userId, name: newProfileName)
                profiles = try await APIClient.shared.fetchChatProfiles(userId: userId)
                selectedProfileId = profiles.last?.id
                showingUnclassified = false
                await loadConversations()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func updateProfileDisplayName() {
        guard let userId = session.currentUserId,
              let selectedProfileId else { return }
        Task {
            do {
                try await APIClient.shared.updateChatProfileDisplayName(
                    userId: userId,
                    profileId: selectedProfileId,
                    displayName: profileDisplayName)
                profiles = try await APIClient.shared.fetchChatProfiles(userId: userId)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func addContact() {
        guard let userId = session.currentUserId, let selectedProfileId else { return }
        Task {
            do {
                try await APIClient.shared.addProfileContact(
                    userId: userId, profileId: selectedProfileId, email: contactEmail)
                showingUnclassified = false
                await loadConversations()
                await loadUnclassifiedConversations()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func addContact(publicUserId: String) {
        guard let userId = session.currentUserId, let selectedProfileId else {
            errorMessage = "追加先のプロファイルを選択してください。"
            return
        }
        Task {
            do {
                try await APIClient.shared.addProfileContact(
                    userId: userId,
                    profileId: selectedProfileId,
                    publicUserId: publicUserId)
                showingUnclassified = false
                await loadConversations()
                await loadUnclassifiedConversations()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func startNewChat() {
        guard let userId = session.currentUserId, let selectedProfileId,
              !newTargetEmail.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        let email = newTargetEmail.trimmingCharacters(in: .whitespacesAndNewlines)
        Task {
            do {
                try await APIClient.shared.addProfileContact(
                    userId: userId, profileId: selectedProfileId, email: email)
                showingUnclassified = false
                await loadUnclassifiedConversations()
                activeChatEmail = email
                isNavigateToChat = true
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func assignPendingContact(to profile: ChatProfileDto) {
        guard let userId = session.currentUserId,
              let contactUserId = pendingAssignment?.targetUserId else { return }
        Task {
            do {
                try await APIClient.shared.assignContact(
                    userId: userId, profileId: profile.id, contactUserId: contactUserId)
                conversationToMove = nil
                selectedProfileId = profile.id
                showingUnclassified = false
                pendingAssignment = nil
                await loadConversations()
                await loadUnclassifiedConversations()
                activeChatEmail = conversations.first(where: { $0.targetUserId == contactUserId })?.targetEmail
                if activeChatEmail != nil {
                    isNavigateToChat = true
                }
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func moveConversation(to profile: ChatProfileDto) {
        guard let userId = session.currentUserId,
              let contactUserId = conversationToMove?.targetUserId else { return }
        Task {
            do {
                try await APIClient.shared.assignContact(
                    userId: userId, profileId: profile.id, contactUserId: contactUserId)
                conversationToMove = nil
                await loadConversations()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func deleteConversation(deleteForBoth: Bool) {
        guard let userId = session.currentUserId,
              let conversation = conversationToDelete,
              let targetUserId = conversation.targetUserId else { return }
        Task {
            do {
                try await APIClient.shared.deleteConversation(
                    userId: userId,
                    targetUserId: targetUserId,
                    profileId: showingUnclassified ? nil : selectedProfileId,
                    deleteForBoth: deleteForBoth)
                conversationToDelete = nil
                await loadConversations()
                await loadUnclassifiedConversations()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func deleteSelectedProfile() {
        guard let userId = session.currentUserId, let selectedProfileId else { return }
        Task {
            do {
                try await APIClient.shared.deleteChatProfile(userId: userId, profileId: selectedProfileId)
                profiles = try await APIClient.shared.fetchChatProfiles(userId: userId)
                self.selectedProfileId = profiles.first(where: \.defaultProfile)?.id
                showingUnclassified = false
                await loadConversations()
                await loadUnclassifiedConversations()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }
}
