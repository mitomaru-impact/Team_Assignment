import AVFAudio
import Foundation
@preconcurrency import WebRTC

final class P2PCallConnection: NSObject {
    var onLocalCandidate: ((RTCIceCandidate) -> Void)?
    var onConnectionStateChanged: ((RTCIceConnectionState) -> Void)?

    private static let factory: RTCPeerConnectionFactory = {
        RTCInitializeSSL()
        return RTCPeerConnectionFactory(
            encoderFactory: RTCDefaultVideoEncoderFactory(),
            decoderFactory: RTCDefaultVideoDecoderFactory())
    }()

    private let peerConnection: RTCPeerConnection
    private let localAudioTrack: RTCAudioTrack
    private let mediaConstraints = RTCMediaConstraints(
        mandatoryConstraints: [kRTCMediaConstraintsOfferToReceiveAudio: kRTCMediaConstraintsValueTrue],
        optionalConstraints: nil)

    private override init() {
        fatalError("Use P2PCallConnection.create()")
    }

    private init(peerConnection: RTCPeerConnection, localAudioTrack: RTCAudioTrack) {
        self.peerConnection = peerConnection
        self.localAudioTrack = localAudioTrack
        super.init()
        peerConnection.delegate = self
        peerConnection.add(localAudioTrack, streamIds: ["audio-stream"])
    }

    static func create() throws -> P2PCallConnection {
        let configuration = RTCConfiguration()
        configuration.iceServers = [
            RTCIceServer(urlStrings: ["stun:stun.l.google.com:19302"])
        ]
        configuration.sdpSemantics = .unifiedPlan

        let constraints = RTCMediaConstraints(mandatoryConstraints: nil, optionalConstraints: nil)
        guard let connection = Self.factory.peerConnection(
            with: configuration,
            constraints: constraints,
            delegate: nil
        ) else {
            throw NSError(
                domain: "P2PCallConnection",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "WebRTC peer connectionを作成できませんでした"])
        }

        let audioSource = Self.factory.audioSource(
            with: RTCMediaConstraints(mandatoryConstraints: nil, optionalConstraints: nil))
        let audioTrack = Self.factory.audioTrack(with: audioSource, trackId: UUID().uuidString)
        let result = P2PCallConnection(peerConnection: connection, localAudioTrack: audioTrack)

        let audioSession = AVAudioSession.sharedInstance()
        try audioSession.setCategory(.playAndRecord, mode: .voiceChat, options: [.allowBluetooth, .defaultToSpeaker])
        return result
    }

    func createOffer() async throws -> String {
        let description: RTCSessionDescription = try await withCheckedThrowingContinuation { continuation in
            peerConnection.offer(for: mediaConstraints) { [weak self] sdp, error in
                guard let self else {
                    continuation.resume(throwing: CancellationError())
                    return
                }
                guard let sdp else {
                    continuation.resume(throwing: error ?? self.webRTCError("通話オファーを作成できませんでした"))
                    return
                }
                self.peerConnection.setLocalDescription(sdp) { error in
                    if let error {
                        continuation.resume(throwing: error)
                    } else {
                        continuation.resume(returning: sdp)
                    }
                }
            }
        }
        return description.sdp
    }

    func applyOfferAndCreateAnswer(_ sdp: String) async throws -> String {
        try await setRemoteDescription(type: .offer, sdp: sdp)
        let description: RTCSessionDescription = try await withCheckedThrowingContinuation { continuation in
            peerConnection.answer(for: mediaConstraints) { [weak self] answer, error in
                guard let self else {
                    continuation.resume(throwing: CancellationError())
                    return
                }
                guard let answer else {
                    continuation.resume(throwing: error ?? self.webRTCError("通話応答を作成できませんでした"))
                    return
                }
                self.peerConnection.setLocalDescription(answer) { error in
                    if let error {
                        continuation.resume(throwing: error)
                    } else {
                        continuation.resume(returning: answer)
                    }
                }
            }
        }
        return description.sdp
    }

    func applyAnswer(_ sdp: String) async throws {
        try await setRemoteDescription(type: .answer, sdp: sdp)
    }

    func addRemoteCandidate(_ candidate: RTCIceCandidate) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            peerConnection.add(candidate) { error in
                if let error {
                    continuation.resume(throwing: error)
                } else {
                    continuation.resume()
                }
            }
        }
    }

    func setMuted(_ muted: Bool) {
        localAudioTrack.isEnabled = !muted
    }

    func close() {
        peerConnection.close()
    }

    private func setRemoteDescription(type: RTCSdpType, sdp: String) async throws {
        let description = RTCSessionDescription(type: type, sdp: sdp)
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            peerConnection.setRemoteDescription(description) { error in
                if let error {
                    continuation.resume(throwing: error)
                } else {
                    continuation.resume()
                }
            }
        }
    }

    private func webRTCError(_ message: String) -> NSError {
        NSError(domain: "P2PCallConnection", code: 2, userInfo: [NSLocalizedDescriptionKey: message])
    }
}

extension P2PCallConnection: RTCPeerConnectionDelegate {
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange stateChanged: RTCSignalingState) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didAdd stream: RTCMediaStream) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove stream: RTCMediaStream) {}
    func peerConnectionShouldNegotiate(_ peerConnection: RTCPeerConnection) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceConnectionState) {
        onConnectionStateChanged?(newState)
    }
    func peerConnection(_ peerConnection: RTCPeerConnection, didChange newState: RTCIceGatheringState) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didGenerate candidate: RTCIceCandidate) {
        onLocalCandidate?(candidate)
    }
    func peerConnection(_ peerConnection: RTCPeerConnection, didRemove candidates: [RTCIceCandidate]) {}
    func peerConnection(_ peerConnection: RTCPeerConnection, didOpen dataChannel: RTCDataChannel) {}
}
