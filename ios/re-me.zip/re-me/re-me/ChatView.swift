// ChatView.swift

import SwiftUI
import UIKit

struct ChatView: View {
    private let availableReactions = [
        ReactionOption(emoji: "👍", title: "いいね"),
        ReactionOption(emoji: "❤️", title: "ハート"),
        ReactionOption(emoji: "😂", title: "笑い"),
        ReactionOption(emoji: "😮", title: "びっくり"),
        ReactionOption(emoji: "😢", title: "悲しい"),
        ReactionOption(emoji: "🙏", title: "ありがとう")
    ]

    @Environment(\.dismiss) private var dismiss
    @ObservedObject private var session = AppSession.shared
    @ObservedObject private var messageSocket = MessageSocket.shared
    @ObservedObject private var callManager = CallManager.shared

    let targetEmail: String
    var targetName: String? = nil
    var profileId: Int64? = nil
    var groupId: String? = nil

    @State private var resolvedTargetName: String?
    @State private var messageText: String = ""
    @State private var searchText = ""
    @State private var isSearching = false
    @State private var messages: [MessageDto] = []
    @State private var typingUserIds: Set<String> = []
    @State private var typingTimeoutTask: Task<Void, Never>?
    @State private var isLocallyTyping = false
    @State private var replyToMessage: MessageDto?
    @State private var editingMessage: MessageDto?
    @State private var messageDraftRevision = 0
    @State private var isSending = false
    @State private var isLoading = false
    @State private var errorMessage: String?
    @State private var messageLoadGeneration = 0
    @State private var isGroupCreator = false
    @State private var conversationMuteMode = "NONE"
    @State private var mentionCandidates: [MentionCandidate] = []
    @State private var showingGroupMembers = false
    @State private var showingStartCallConfirmation = false
    @State private var showingRecallConfirmation = false
    @State private var messageToRecall: MessageDto?
    @State private var translationStates: [Int64: TranslationState] = [:]
    @AppStorage("translationSuggestionsEnabled") private var translationSuggestionsEnabled = true
    @State private var showingDeleteConversationConfirmation = false
    @State private var showingLeaveGroupConfirmation = false
    @State private var showingDeleteGroupConfirmation = false
    @State private var showingBlockConfirmation = false
    @State private var isBlockedByMe = false
    @FocusState private var isSearchFieldFocused: Bool

    var body: some View {
        VStack(spacing: 0) {
            if isSearching {
                HStack(spacing: 8) {
                    Image(systemName: "magnifyingglass")
                        .foregroundStyle(.secondary)
                    TextField("メッセージを検索", text: $searchText)
                        .focused($isSearchFieldFocused)
                        .submitLabel(.search)
                    if !searchText.isEmpty {
                        Text("\(displayedMessages.count)件")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Button {
                            searchText = ""
                            isSearchFieldFocused = true
                        } label: {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundStyle(.secondary)
                        }

                        .accessibilityLabel("検索文字を消去")
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 9)
                .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12))
                .padding(.horizontal)
                .padding(.vertical, 8)
            }

            ScrollViewReader { proxy in
                ScrollView {
                    messageListContent
                }
                .defaultScrollAnchor(.bottom)
                .scrollDismissesKeyboard(.interactively)
                .background(Color(.systemGroupedBackground))
                .onChange(of: messages.count) { oldCount, newCount in
                    guard searchText.isEmpty else { return }
                    guard newCount > 0 else { return }
                    if let lastMsg = messages.last {
                        if oldCount == 0 {
                            proxy.scrollTo(lastMsg.id, anchor: .bottom)
                        } else {
                            withAnimation {
                                proxy.scrollTo(lastMsg.id, anchor: .bottom)
                            }
                        }
                    }
                }
                .onChange(of: searchText) { _, newValue in
                    guard !newValue.isEmpty, let firstMatch = displayedMessages.first else { return }
                    withAnimation {
                        proxy.scrollTo(firstMatch.id, anchor: .top)
                    }
                }
            }

            if let errorMessage {
                Label(errorMessage, systemImage: "exclamationmark.triangle")
                    .font(.footnote)
                    .foregroundStyle(.red)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal)
                    .padding(.top, 8)
            }

            VStack(spacing: 8) {
                if let replyToMessage {
                    HStack(spacing: 8) {
                        Image(systemName: "arrowshape.turn.up.left")
                            .foregroundStyle(.tint)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(replyToMessage.senderDisplayName
                                 ?? (replyToMessage.senderId == session.currentUserId ? "自分" : displayName))
                                .font(.caption.weight(.semibold))
                            Text(replyToMessage.content)
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .lineLimit(1)
                        }
                        if let editingMessage {
                            HStack(spacing: 8) {
                                Image(systemName: "pencil")
                                    .foregroundStyle(.tint)
                                Text("メッセージを編集")
                                    .font(.caption.weight(.semibold))
                                Spacer()
                                Button {
                                    self.editingMessage = nil
                                    messageText = ""
                                } label: {
                                    Image(systemName: "xmark.circle.fill")
                                        .foregroundStyle(.secondary)
                                }
                                .accessibilityLabel("編集をキャンセル")
                            }
                            .padding(.horizontal, 12)
                            .padding(.top, 8)
                        }
                        Spacer()
                        Button {
                            self.replyToMessage = nil
                        } label: {
                            Image(systemName: "xmark.circle.fill")
                                .foregroundStyle(.secondary)
                        }
                        .accessibilityLabel("返信をキャンセル")
                    }
                    .padding(.horizontal, 12)
                    .padding(.top, 8)
                }

                if !typingUserIds.isEmpty {
                    HStack(spacing: 7) {
                        TypingIndicatorDots()
                        Text("入力中...")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                        Spacer()
                    }
                    .padding(.horizontal, 16)
                    .transition(.opacity.combined(with: .move(edge: .bottom)))
                }

                mentionSuggestionBar

                HStack(alignment: .center, spacing: 8) {
                    TextField("メッセージ", text: Binding(
                        get: { messageText },
                        set: { newValue in
                            updateMessageDraft(newValue)
                        }), axis: .vertical)
                        .textFieldStyle(.plain)
                        .submitLabel(.send)
                        .lineLimit(1...4)
                        .onSubmit {
                            submitMessage()
                        }

                    Button {
                        updateMessageDraft(messageText + "@")
                    } label: {
                        Image(systemName: "at")
                            .font(.system(size: 19, weight: .medium))
                            .foregroundStyle(.secondary)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("メンションを入力")

                    Button(action: submitMessage) {
                        if isSending {
                            ProgressView()
                                .frame(width: 36, height: 36)
                        } else {
                            Image(systemName: "arrow.up.circle.fill")
                                .font(.system(size: 34))
                                .symbolRenderingMode(.hierarchical)
                        }
                    }
                    .tint(.accentColor)
                    .disabled(isSending || messageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                              || !hasConversationTarget)
                    .accessibilityLabel("メッセージを送信")
                    .contextMenu {
                        Button {
                            submitMessage()
                        } label: {
                            Label("通常メッセージ", systemImage: "paperplane")
                        }
                        Button {
                            sendSilentMessage()
                        } label: {
                            Label("サイレントメッセージ", systemImage: "bell.slash")
                        }
                        .disabled(editingMessage != nil)
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 22))
                .padding(.horizontal)
                .padding(.bottom, 8)
            }
            .background(Color(.systemBackground))
        }
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
            ToolbarItem(placement: .principal) {
                VStack(spacing: 1) {
                    Text(displayName)
                        .font(.headline)
                    if groupId == nil && messageSocket.onlineUsers.contains(targetEmail.lowercased()) {
                        Text("オンライン")
                            .font(.caption2)
                            .foregroundStyle(.secondary)
                    }
                }
            }
            ToolbarItem(placement: .topBarTrailing) {
                HStack(spacing: 16) {
                    if groupId == nil {
                        Button {
                            showingStartCallConfirmation = true
                        } label: {
                            Image(systemName: "phone")
                        }
                        .disabled(targetEmail.isEmpty || callManager.isStartingCall)
                        .accessibilityLabel("音声通話を発信")
                    }

                    Menu {
                        Button(
                            isSearching ? "検索を閉じる" : "メッセージを検索",
                            systemImage: isSearching ? "xmark" : "magnifyingglass"
                        ) {
                            isSearching.toggle()
                            if isSearching {
                                isSearchFieldFocused = true
                            } else {
                                searchText = ""
                                isSearchFieldFocused = false
                            }
                        }
                        Button("メッセージを更新", systemImage: "arrow.clockwise") {
                            loadMessages()
                        }
                        if conversationMuteMode == "NONE" {
                            Menu {
                                Button("メンションは通知する", systemImage: "at") {
                                    updateConversationMute(mode: "MENTIONS_ONLY")
                                }
                                Button("すべてのメッセージをミュート", systemImage: "bell.slash.fill") {
                                    updateConversationMute(mode: "ALL")
                                }
                            } label: {
                                Label("ミュートする", systemImage: "bell.slash")
                            }
                        } else {
                            Button("ミュートを解除", systemImage: "bell") {
                                updateConversationMute(mode: "NONE")
                            }
                        }

                        if groupId != nil {
                            Button("メンバーを管理", systemImage: "person.2") {
                                showingGroupMembers = true
                            }
                            Button("グループから退出", systemImage: "rectangle.portrait.and.arrow.right", role: .destructive) {
                                showingLeaveGroupConfirmation = true
                            }
                            if isGroupCreator {
                                Button("グループを削除", systemImage: "trash", role: .destructive) {
                                    showingDeleteGroupConfirmation = true
                                }
                            }
                        } else {
                            Button(
                                isBlockedByMe ? "ユーザーのブロックを解除" : "ユーザーをブロック",
                                systemImage: isBlockedByMe ? "person.crop.circle.badge.checkmark" : "person.crop.circle.badge.xmark",
                                role: isBlockedByMe ? nil : .destructive
                            ) {
                                showingBlockConfirmation = true
                            }
                            Button("メッセージを削除", systemImage: "trash", role: .destructive) {
                                showingDeleteConversationConfirmation = true
                            }
                        }
                    } label: {
                        Image(systemName: "line.3.horizontal")
                    }
                    .accessibilityLabel("トークメニュー")
                }
            }
        }
        .animation(.easeInOut(duration: 0.2), value: typingUserIds.isEmpty)
        .onAppear {
            if let groupId {
                messageSocket.setActiveGroupConversation(id: groupId)
            } else {
                messageSocket.setActiveConversation(email: targetEmail)
            }
            loadBlockStatus()
            loadMessages()
            loadDisplayNameIfNeeded()
            loadConversationMute()
            loadMentionCandidates()
            markConversationAsRead()
            loadGroupPermissions()
        }
        .onDisappear {
            stopTyping()
            if let groupId {
                messageSocket.clearActiveGroupConversation(id: groupId)
            } else {
                messageSocket.clearActiveConversation(email: targetEmail)
            }
        }
        .onChange(of: messageSocket.latestMessageRevision) { _, _ in
            loadMessages()
            markConversationAsRead()
        }
        .onChange(of: messageSocket.messageReactionRevision) { _, _ in
            guard let event = messageSocket.messageReactionEvent else { return }
            if let groupId {
                guard event.groupId == groupId else { return }
            } else {
                guard event.partnerEmail?.caseInsensitiveCompare(targetEmail) == .orderedSame else { return }
            }
            loadMessages()
        }
        .onChange(of: messageSocket.messageRecallRevision) { _, _ in
            guard let event = messageSocket.messageRecallEvent else { return }
            if let groupId {
                guard event.groupId == groupId else { return }
            } else {
                guard event.partnerEmail?.caseInsensitiveCompare(targetEmail) == .orderedSame else { return }
            }
            loadMessages()
        }
        .onChange(of: messageSocket.typingRevision) { _, _ in
            guard let event = messageSocket.typingEvent,
                  event.senderId != session.currentUserId else { return }
            if let groupId {
                guard event.groupId == groupId else { return }
            } else {
                guard event.partnerEmail?.caseInsensitiveCompare(targetEmail) == .orderedSame else { return }
            }
            if event.isTyping {
                typingUserIds.insert(event.senderId)
            } else {
                typingUserIds.remove(event.senderId)
            }
        }
        .onChange(of: messageSocket.readReceiptRevision) { _, _ in
            guard groupId == nil,
                  let event = messageSocket.readReceiptEvent,
                  let currentUserId = session.currentUserId else { return }
            let messageIds = Set(event.messageIds)
            for index in messages.indices where messageIds.contains(messages[index].id)
                && messages[index].senderId == currentUserId
                && messages[index].receiverId == event.readerId {
                messages[index].readStatus = true
            }
        }
        .onChange(of: messageSocket.conversationDeletionRevision) { _, _ in
            guard let event = messageSocket.conversationDeletionEvent,
                  event.partnerEmail.caseInsensitiveCompare(targetEmail) == .orderedSame else { return }
            if event.forceClose {
                messageLoadGeneration += 1
                messages = []
                dismiss()
            } else {
                loadMessages()
            }
        }
        .onChange(of: messageSocket.profileIdentityRevision) { _, _ in
            guard groupId == nil else { return }
            guard let event = messageSocket.profileIdentityEvent,
                  event.partnerEmail.caseInsensitiveCompare(targetEmail) == .orderedSame else { return }
            loadContactDisplayName()
            loadMessages()
        }
        .onChange(of: messageSocket.groupChangeRevision) { _, _ in
            guard let groupId,
                  let event = messageSocket.groupChangeEvent,
                  event.groupId == groupId else { return }
            if event.type == "group_deleted"
                || (event.type == "group_member_removed" && event.userId == session.currentUserId) {
                messageLoadGeneration += 1
                messages = []
                dismiss()
            } else if event.type == "group_read_receipt" {
                loadMessages()
            } else {
                loadGroupPermissions()
            }
        }
        .sheet(isPresented: $showingGroupMembers) {
            if let groupId, let userId = session.currentUserId {
                NavigationStack {
                    GroupMemberManagementView(
                        userId: userId,
                        groupId: groupId,
                        profileId: profileId)
                }
            }
        }
        .alert("通話を開始しますか？", isPresented: $showingStartCallConfirmation) {
            Button("発信") {
                Task {
                    await callManager.startCall(targetEmail: targetEmail, peerName: displayName)
                }
            }
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("\(displayName)に音声通話を発信します。")
        }
        .alert("送信を取り消しますか？", isPresented: $showingRecallConfirmation) {
            Button("取り消す", role: .destructive) {
                recallMessage()
            }
            Button("キャンセル", role: .cancel) {
                messageToRecall = nil
            }
        } message: {
            Text("相手の画面からもメッセージが取り消されます。")
        }
        .confirmationDialog(
            "メッセージを削除",
            isPresented: $showingDeleteConversationConfirmation,
            titleVisibility: .visible
        ) {
            Button("自分の画面から削除", role: .destructive) {
                deleteConversation(deleteForBoth: false)
            }
            Button("双方の画面から削除", role: .destructive) {
                deleteConversation(deleteForBoth: true)
            }
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("双方から削除すると、相手側のトーク履歴も削除されます。")
        }
        .confirmationDialog(
            "このグループから退出しますか？",
            isPresented: $showingLeaveGroupConfirmation,
            titleVisibility: .visible
        ) {
            Button("退出", role: .destructive) {
                leaveConversation()
            }
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("グループのメンバーではなくなり、トーク一覧から削除されます。")
        }
        .confirmationDialog(
            "グループを削除しますか？",
            isPresented: $showingDeleteGroupConfirmation,
            titleVisibility: .visible
        ) {
            Button("グループを削除", role: .destructive) {
                deleteGroup()
            }
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text("グループとすべてのメッセージが、全メンバーの画面から削除されます。この操作は取り消せません。")
        }
        .confirmationDialog(
            isBlockedByMe ? "ユーザーのブロックを解除しますか？" : "ユーザーをブロックしますか？",
            isPresented: $showingBlockConfirmation,
            titleVisibility: .visible
        ) {
            Button(isBlockedByMe ? "ブロックを解除" : "ブロック", role: isBlockedByMe ? nil : .destructive) {
                updateBlockStatus()
            }
            Button("キャンセル", role: .cancel) {}
        } message: {
            Text(isBlockedByMe
                 ? "このユーザーからのブロックを解除します。"
                 : "このユーザーからのメッセージと通知を受け取らなくなります。")
        }
    }

    private var displayName: String {
        resolvedTargetName ?? targetName ?? targetEmail
    }

    private var currentMentionQuery: String? {
        guard let at = messageText.range(of: "@", options: .backwards) else { return nil }
        if let preceding = messageText[..<at.lowerBound].last, !preceding.isWhitespace {
            return nil
        }
        return String(messageText[at.upperBound...])
    }

    private var matchingMentionCandidates: [MentionCandidate] {
        guard let query = currentMentionQuery else { return [] }
        var candidates = mentionCandidates
        if groupId != nil {
            candidates.insert(
                MentionCandidate(
                    id: "everyone",
                    username: "everyone",
                    displayName: "全員",
                    token: "everyone"),
                at: 0)
        }
        let normalizedQuery = query.lowercased()
        return candidates.filter {
            normalizedQuery.isEmpty
                || $0.displayName.lowercased().contains(normalizedQuery)
                || $0.token.lowercased().contains(normalizedQuery)
        }
    }

    @ViewBuilder
    private var mentionSuggestionBar: some View {
        if !matchingMentionCandidates.isEmpty {
            ScrollView {
                VStack(alignment: .leading, spacing: 0) {
                    ForEach(matchingMentionCandidates) { candidate in
                        Button {
                            insertMention(candidate.token)
                        } label: {
                            HStack {
                                Text("@\(candidate.displayName)")
                                    .foregroundStyle(.primary)
                                Text(candidate.username)
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                                Spacer()
                            }
                            .padding(.horizontal, 14)
                            .padding(.vertical, 9)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .frame(maxHeight: 150)
            .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 12))
            .padding(.horizontal)
        }
    }

    private func loadConversationMute() {
        guard let userId = session.currentUserId else { return }
        Task {
            do {
                let mutes = try await APIClient.shared.fetchConversationMutes(userId: userId)
                if let groupId {
                    conversationMuteMode = mutes.first(where: { $0.groupId == groupId })?.mode ?? "NONE"
                } else {
                    conversationMuteMode = mutes.first(where: {
                        $0.targetEmail?.caseInsensitiveCompare(targetEmail) == .orderedSame
                    })?.mode ?? "NONE"
                }
            } catch {
                errorMessage = "ミュート設定を読み込めませんでした: \(error.localizedDescription)"
            }
        }
    }

    private func loadBlockStatus() {
        guard groupId == nil, let userId = session.currentUserId else { return }
        Task {
            do {
                let blockedUsers = try await APIClient.shared.fetchBlockedUsers(userId: userId)
                isBlockedByMe = blockedUsers.contains {
                    $0.email.caseInsensitiveCompare(targetEmail) == .orderedSame
                }
            } catch {
                errorMessage = "ブロック設定を読み込めませんでした: \(error.localizedDescription)"
            }
        }
    }

    private func updateBlockStatus() {
        guard groupId == nil, let userId = session.currentUserId else { return }
        Task {
            do {
                if isBlockedByMe {
                    try await APIClient.shared.unblockUser(
                        userId: userId,
                        targetEmail: targetEmail)
                    isBlockedByMe = false
                } else {
                    try await APIClient.shared.blockUser(
                        userId: userId,
                        targetEmail: targetEmail)
                    isBlockedByMe = true
                }
            } catch {
                errorMessage = "ブロック設定を保存できませんでした: \(error.localizedDescription)"
            }
        }
    }

    private func updateConversationMute(mode: String) {
        guard let userId = session.currentUserId else { return }
        Task {
            do {
                try await APIClient.shared.updateConversationMute(
                    userId: userId,
                    targetEmail: groupId == nil ? targetEmail : nil,
                    groupId: groupId,
                    mode: mode)
                conversationMuteMode = mode
            } catch {
                errorMessage = "ミュート設定を保存できませんでした: \(error.localizedDescription)"
            }
        }
    }

    private var hasConversationTarget: Bool {
        groupId != nil || !targetEmail.isEmpty
    }

    private var displayedMessages: [MessageDto] {
        guard !searchText.isEmpty else { return messages }
        return messages.filter { $0.content.localizedCaseInsensitiveContains(searchText) }
    }

    @ViewBuilder
    private var messageListContent: some View {
        if messages.isEmpty && isLoading {
            ProgressView("メッセージを読み込み中")
                .frame(maxWidth: .infinity, minHeight: 220)
        } else if messages.isEmpty && errorMessage == nil {
            ContentUnavailableView(
                "メッセージはまだありません",
                systemImage: "bubble.left.and.bubble.right",
                description: Text("最初のメッセージを送ってみましょう。"))
                .frame(maxWidth: .infinity, minHeight: 280)
        } else if !searchText.isEmpty && displayedMessages.isEmpty {
            ContentUnavailableView(
                "該当するメッセージがありません",
                systemImage: "magnifyingglass",
                description: Text("別のキーワードで検索してください。"))
                .frame(maxWidth: .infinity, minHeight: 220)
        } else {
            LazyVStack(alignment: .leading, spacing: 12) {
                ForEach(displayedMessages) { message in
                    messageRow(message)
                }
            }
            .padding(.vertical, 12)
        }
    }

    private func loadGroupPermissions() {
        guard let groupId, let userId = session.currentUserId else { return }
        Task {
            do {
                let members = try await APIClient.shared.fetchGroupMembers(userId: userId, groupId: groupId)
                isGroupCreator = members.contains { $0.publicUserId == userId && $0.creator }
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func leaveConversation() {
        guard let userId = session.currentUserId else { return }
        Task {
            do {
                if let groupId {
                    try await APIClient.shared.leaveGroup(userId: userId, groupId: groupId)
                } else {
                    try await APIClient.shared.leaveConversation(
                        userId: userId,
                        targetEmail: targetEmail,
                        profileId: profileId)
                }
                dismiss()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func deleteConversation(deleteForBoth: Bool) {
        guard let userId = session.currentUserId, groupId == nil else { return }
        Task {
            do {
                try await APIClient.shared.deleteConversation(
                    userId: userId,
                    targetEmail: targetEmail,
                    profileId: profileId,
                    deleteForBoth: deleteForBoth)
                dismiss()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func deleteGroup() {
        guard let groupId, let userId = session.currentUserId else { return }
        Task {
            do {
                try await APIClient.shared.deleteGroup(userId: userId, groupId: groupId)
                dismiss()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    @ViewBuilder
    private func callLogRow(_ message: MessageDto) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "phone.arrow.down.left")
                .foregroundStyle(.secondary)
            Text("通話終了 - \(formattedCallDuration(message.callDurationSeconds ?? 0))")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text(formatTime(message.createdAt))
                .font(.caption2)
                .foregroundStyle(.tertiary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 8)
        .id(message.id)
    }

    @ViewBuilder
    private func messageRow(_ message: MessageDto) -> some View {
        if message.recalled == true || message.type == "RECALLED" {
            recalledMessageRow(message)
        } else if message.type == "CALL_LOG" {
            callLogRow(message)
        } else {
            regularMessageRow(message)
        }
    }

    private func recalledMessageRow(_ message: MessageDto) -> some View {
        HStack(spacing: 6) {
            Image(systemName: "arrow.uturn.backward")
            Text("メッセージの送信を取り消しました")
        }
        .font(.caption)
        .italic()
        .foregroundStyle(.secondary)
        .frame(maxWidth: .infinity, alignment: .center)
        .padding(.vertical, 6)
        .id(message.id)
    }

    private func regularMessageRow(_ message: MessageDto) -> some View {
        let isMe = session.currentUserId == message.senderId
        return HStack {
            if isMe {
                Spacer(minLength: 48)
            }
            VStack(alignment: isMe ? .trailing : .leading, spacing: 4) {
                if let senderName = message.senderDisplayName {
                    Text(senderName)
                        .font(.caption2.weight(.medium))
                        .foregroundStyle(.secondary)
                }
                if let replyContent = message.replyToContent {
                    replyPreview(replyContent, senderName: message.replyToSenderName, isMe: isMe)
                }
                messageBody(message, isOutgoing: isMe)
                if message.edited == true {
                    Text("編集済み")
                        .font(.caption2)
                        .foregroundStyle(.secondary)
                }

                if let reactions = message.reactions, !reactions.isEmpty {
                    HStack(spacing: 6) {
                        ForEach(reactions) { reaction in
                            Button {
                                toggleReaction(reaction.emoji, for: message)
                            } label: {
                                Text(reaction.emoji)
                                    .font(.caption)
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 4)
                                    .background(
                                        reaction.reactedByMe
                                            ? Color.accentColor.opacity(0.16)
                                            : Color(.secondarySystemGroupedBackground),
                                        in: Capsule())
                                    .overlay {
                                        Capsule()
                                            .stroke(
                                                reaction.reactedByMe ? Color.accentColor : .clear,
                                                lineWidth: 1)
                                    }
                            }
                            .buttonStyle(.plain)
                            .accessibilityLabel(
                                "\(reactionTitle(for: reaction.emoji))、\(reaction.count)件")
                        }
                    }
                }
                HStack(spacing: 4) {
                    if isMe {
                        if let groupId, let readCount = message.readCount, readCount > 0 {
                            Text("既読 \(readCount)")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        } else if groupId == nil && message.readStatus == true {
                            Text("既読")
                                .font(.caption2)
                                .foregroundStyle(.secondary)
                        }
                    }
                    Text(formatTime(message.createdAt))
                        .font(.caption2)
                        .foregroundColor(.secondary)
                }
            }
            if !isMe {
                Spacer(minLength: 48)
            }
        }
        .padding(.horizontal)
        .contextMenu {
            if isMe {
                Button {
                    editingMessage = message
                    messageText = message.content
                    replyToMessage = nil
                } label: {
                    Label("編集", systemImage: "pencil")
                }
                Button(role: .destructive) {
                    messageToRecall = message
                    showingRecallConfirmation = true
                } label: {
                    Label("送信を取り消す", systemImage: "arrow.uturn.backward")
                }
            }
            Button {
                replyToMessage = message
            } label: {
                Label("返信", systemImage: "arrowshape.turn.up.left")
            }
            Button {
                UIPasteboard.general.string = message.content
            } label: {
                Label("コピー", systemImage: "doc.on.doc")
            }
            Menu {
                ForEach(availableReactions) { reaction in
                    Button {
                        toggleReaction(reaction.emoji, for: message)
                    } label: {
                        Text("\(reaction.emoji) \(reaction.title)")
                    }
                }
            } label: {
                Label("リアクション", systemImage: "face.smiling")
            }

            Button {} label: {
                Label("送信日時: \(formatFullDateTime(message.createdAt))", systemImage: "clock")
            }
            .disabled(true)
        }
        .id(message.id)
    }

    @ViewBuilder
    private func messageBody(_ message: MessageDto, isOutgoing: Bool) -> some View {
        if isEmojiOnlyMessage(message.content) {
            Text(message.content)
                .font(.system(size: 48))
                .lineSpacing(4)
                .multilineTextAlignment(isOutgoing ? .trailing : .leading)
                .frame(maxWidth: 280, alignment: isOutgoing ? .trailing : .leading)
                .accessibilityLabel(message.content)
        } else {
            VStack(alignment: .leading, spacing: 6) {
                styledMessageContent(message, isOutgoing: isOutgoing)
                translationView(for: message, isOutgoing: isOutgoing)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 10)
            .background(
                isOutgoing ? Color.accentColor : Color(.secondarySystemGroupedBackground))
            .foregroundColor(isOutgoing ? .white : .primary)
            .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
    }

    private func isEmojiOnlyMessage(_ content: String) -> Bool {
        let characters = Array(content.trimmingCharacters(in: .whitespacesAndNewlines))
        guard !characters.isEmpty else { return false }

        var containsEmoji = false
        for character in characters {
            let scalars = Array(character.unicodeScalars)
            guard !scalars.isEmpty else { return false }
            guard scalars.contains(where: { $0.value > 0x7F || $0 == "\u{FE0F}" }) else {
                return false
            }
            if scalars.contains(where: { $0.properties.isEmoji }) {
                containsEmoji = true
            }
            guard scalars.allSatisfy({
                $0.properties.isEmoji
                    || $0 == "\u{FE0E}"
                    || $0 == "\u{FE0F}"
                    || $0 == "\u{200D}"
                    || ($0.value >= 0x1F3FB && $0.value <= 0x1F3FF)
                    || $0.value == 0x20E3
            }) else {
                return false
            }
        }
        return containsEmoji
    }

    @ViewBuilder
    private func translationView(for message: MessageDto, isOutgoing: Bool) -> some View {
        if shouldOfferTranslation(for: message) {
            switch translationStates[message.id] {
            case .loading:
                HStack(spacing: 5) {
                    ProgressView()
                        .controlSize(.small)
                    Text("翻訳中...")
                }
                .font(.caption2)
            .foregroundColor(isOutgoing ? .white.opacity(0.8) : .secondary)
            case .translated(let text):
                VStack(alignment: .leading, spacing: 2) {
                    Text("日本語訳")
                        .font(.caption2.weight(.medium))
                        .foregroundColor(isOutgoing ? .white.opacity(0.8) : .secondary)
                    Text(text)
                        .font(.caption)
                        .foregroundColor(isOutgoing ? .white : .primary)
                        .multilineTextAlignment(.leading)
                }
                .frame(maxWidth: 260, alignment: .leading)
            case .failed:
                Button("翻訳に失敗しました。再試行") {
                    translate(message)
                }
                .font(.caption2)
                .foregroundColor(isOutgoing ? .white.opacity(0.8) : .secondary)
            case .none:
                Button("翻訳しますか？") {
                    translate(message)
                }
                .font(.caption2)
                .foregroundColor(isOutgoing ? .white.opacity(0.8) : .secondary)
            }
        }
    }

    private func shouldOfferTranslation(for message: MessageDto) -> Bool {
        guard translationSuggestionsEnabled else { return false }
        guard Locale.current.language.languageCode?.identifier == "ja" else { return false }
        let text = message.content.trimmingCharacters(in: .whitespacesAndNewlines)
        guard text.count >= 3, text.rangeOfCharacter(from: .letters) != nil else { return false }
        guard text.rangeOfCharacter(from: CharacterSet(charactersIn: "あ-んア-ン一-龯")) == nil else {
            return false
        }

        let letters = text.unicodeScalars.filter { CharacterSet.letters.contains($0) }.count
        let latinLetters = text.unicodeScalars.filter {
            ($0.value >= 0x41 && $0.value <= 0x5A) || ($0.value >= 0x61 && $0.value <= 0x7A)
        }.count
        guard latinLetters >= 3, Double(latinLetters) / Double(max(letters, 1)) >= 0.8 else {
            return false
        }
        guard !text.contains("://"), !text.contains("@") else { return false }
        return true
    }

    private func translate(_ message: MessageDto) {
        guard translationStates[message.id] != .loading else { return }
        translationStates[message.id] = .loading
        Task {
            do {
                let translatedText = try await APIClient.shared.translateMessage(message.content)
                await MainActor.run {
                    translationStates[message.id] = .translated(translatedText)
                }
            } catch {
                await MainActor.run {
                    translationStates[message.id] = .failed(error.localizedDescription)
                }
            }
        }
    }

    private func reactionTitle(for emoji: String) -> String {
        availableReactions.first(where: { $0.emoji == emoji })?.title ?? ""
    }

    private func replyPreview(_ content: String, senderName: String?, isMe: Bool) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(senderName ?? "返信先")
                .font(.caption2.weight(.semibold))
                .foregroundColor(isMe ? .white : .primary)
            Text(content)
                .font(.caption)
                .foregroundColor(isMe ? .white.opacity(0.85) : .secondary)
                .lineLimit(2)
        }
        .frame(maxWidth: 220, alignment: .leading)
        .padding(.horizontal, 10)
        .padding(.vertical, 7)
        .background(isMe ? Color.white.opacity(0.16) : Color.black.opacity(0.06))
        .clipShape(RoundedRectangle(cornerRadius: 10))
    }

    private func formattedCallDuration(_ seconds: Int64) -> String {
        let minutes = seconds / 60
        let remainder = seconds % 60
        if minutes == 0 {
            return "\(remainder)秒"
        }
        if remainder == 0 {
            return "\(minutes)分"
        }
        return "\(minutes)分\(remainder)秒"
    }

    private func toggleReaction(_ emoji: String, for message: MessageDto) {
        guard let userId = session.currentUserId else { return }
        Task {
            do {
                if let groupId {
                    try await APIClient.shared.toggleGroupMessageReaction(
                        userId: userId,
                        groupId: groupId,
                        messageId: message.id,
                        emoji: emoji)
                } else {
                    try await APIClient.shared.toggleMessageReaction(
                        userId: userId,
                        messageId: message.id,
                        emoji: emoji)
                }
                loadMessages()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func recallMessage() {
        guard let userId = session.currentUserId, let message = messageToRecall else { return }
        messageToRecall = nil
        Task {
            do {
                if let groupId {
                    try await APIClient.shared.recallGroupMessage(
                        userId: userId,
                        groupId: groupId,
                        messageId: message.id)
                } else {
                    try await APIClient.shared.recallMessage(userId: userId, messageId: message.id)
                }
                loadMessages()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func updateMessageDraft(_ value: String) {
        messageText = value
        messageDraftRevision += 1
        let shouldType = !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
        typingTimeoutTask?.cancel()

        if shouldType {
            if !isLocallyTyping {
                isLocallyTyping = true
                sendTypingSignal(isTyping: true)
            }
            typingTimeoutTask = Task {
                try? await Task.sleep(for: .seconds(2))
                guard !Task.isCancelled else { return }
                isLocallyTyping = false
                await transmitTypingSignal(isTyping: false)
            }
        } else if isLocallyTyping {
            isLocallyTyping = false
            sendTypingSignal(isTyping: false)
        }
    }

    private func insertMention(_ token: String) {
        guard let at = messageText.range(of: "@", options: .backwards) else { return }
        let updated = String(messageText[..<at.lowerBound]) + "@\(token) "
        updateMessageDraft(updated)
    }

    private func loadMentionCandidates() {
        guard let userId = session.currentUserId else { return }
        Task {
            do {
                if let groupId {
                    let members = try await APIClient.shared.fetchGroupMembers(
                        userId: userId, groupId: groupId)
                    mentionCandidates = members
                        .filter { $0.publicUserId != userId }
                        .map {
                            MentionCandidate(
                                id: $0.publicUserId,
                                username: $0.username ?? $0.displayName,
                                displayName: $0.displayName,
                                token: $0.username ?? $0.displayName)
                        }
                } else {
                    let name = try await APIClient.shared.fetchContactDisplayName(
                        userId: userId, contactEmail: targetEmail)
                    let username = try await APIClient.shared.fetchContactUsername(
                        userId: userId, contactEmail: targetEmail)
                    let nickname = name.caseInsensitiveCompare(targetEmail) == .orderedSame
                        ? displayName
                        : name
                    mentionCandidates = [
                        MentionCandidate(
                            id: targetEmail.lowercased(),
                            username: username,
                            displayName: nickname,
                            token: username)
                    ]
                }
            } catch {
                errorMessage = "メンション候補を読み込めませんでした: \(error.localizedDescription)"
            }
        }
    }

    private func stopTyping() {
        typingTimeoutTask?.cancel()
        typingTimeoutTask = nil
        guard isLocallyTyping else { return }
        isLocallyTyping = false
        sendTypingSignal(isTyping: false)
    }

    private func sendTypingSignal(isTyping: Bool) {
        Task {
            await transmitTypingSignal(isTyping: isTyping)
        }
    }

    private func transmitTypingSignal(isTyping: Bool) async {
        do {
            try await messageSocket.sendTypingSignal(
                targetEmail: groupId == nil ? targetEmail : nil,
                groupId: groupId,
                isTyping: isTyping)
        } catch {
            if isTyping {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func loadDisplayNameIfNeeded() {
        if let groupId {
            guard targetName == nil || targetName == "グループ",
                  let userId = session.currentUserId else { return }
            Task {
                do {
                    let groups = try await APIClient.shared.fetchGroups(userId: userId)
                    resolvedTargetName = groups.first(where: { $0.id == groupId })?.name ?? targetName
                } catch {
                    errorMessage = error.localizedDescription
                }
            }

        } else {
            loadContactDisplayName()
        }
    }

    private struct ReactionOption: Identifiable {
        let emoji: String
        let title: String

        var id: String { emoji }
    }

    private struct MentionCandidate: Identifiable {
        let id: String
        let username: String
        let displayName: String
        let token: String
    }

    private enum TranslationState: Equatable {
        case loading
        case translated(String)
        case failed(String)
    }

    private func styledMessageContent(_ message: MessageDto, isOutgoing: Bool) -> Text {
        let markdownOptions = AttributedString.MarkdownParsingOptions(
            interpretedSyntax: .full,
            failurePolicy: .returnPartiallyParsedIfPossible)
        let markdown = (try? AttributedString(
            markdown: message.content,
            options: markdownOptions)) ?? AttributedString(message.content)
        let styled = NSMutableAttributedString(attributedString: NSAttributedString(markdown))
        let mentionsByRange = Dictionary(
            grouping: message.mentions ?? [],
            by: { "\($0.startIndex):\($0.length)" })
        for mentions in mentionsByRange.values {
            guard let mention = mentions.first(where: \.currentUser) ?? mentions.first else { continue }
            let original = NSString(string: message.content)
            guard mention.startIndex >= 0,
                  mention.length > 0,
                  mention.startIndex + mention.length <= original.length else { continue }
            let token = original.substring(
                with: NSRange(location: mention.startIndex, length: mention.length))
            let range = styled.mutableString.range(of: token)
            guard range.location != NSNotFound else { continue }
            var attributes: [NSAttributedString.Key: Any] = [
                .font: UIFont.systemFont(
                    ofSize: UIFont.preferredFont(forTextStyle: .body).pointSize,
                    weight: .semibold)
            ]
            if !isOutgoing {
                attributes[.foregroundColor] = mention.currentUser
                    ? UIColor.systemOrange
                    : UIColor.systemBlue
            }
            styled.addAttributes(attributes, range: range)
        }
        return Text(AttributedString(styled))
    }

    private struct TypingIndicatorDots: View {
        @State private var isAnimating = false

        var body: some View {
            HStack(spacing: 3) {
                ForEach(0..<3) { index in
                    Circle()
                        .fill(.secondary)
                        .frame(width: 5, height: 5)
                        .scaleEffect(isAnimating ? 1 : 0.55)
                        .opacity(isAnimating ? 1 : 0.45)
                        .animation(
                            .easeInOut(duration: 0.45)
                                .repeatForever()
                                .delay(Double(index) * 0.14),
                            value: isAnimating)
                }
            }
            .onAppear {
                isAnimating = true
            }
        }
    }

    private func loadContactDisplayName() {
        guard groupId == nil, let userId = session.currentUserId else { return }
        Task {
            do {
                resolvedTargetName = try await APIClient.shared.fetchContactDisplayName(
                    userId: userId,
                    contactEmail: targetEmail)
            } catch {
                resolvedTargetName = targetName ?? targetEmail
            }
        }
    }

    private func markConversationAsRead() {
        guard let userId = session.currentUserId, hasConversationTarget else { return }
        Task {
            do {
                if let groupId {
                    try await APIClient.shared.markGroupAsRead(userId: userId, groupId: groupId)
                } else {
                    try await APIClient.shared.markConversationAsRead(userId: userId, targetEmail: targetEmail)
                }
                messageSocket.conversationDidBecomeRead()
                PushNotificationManager.shared.refreshUnreadBadge(userId: userId)
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func formatTime(_ value: String) -> String {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        guard let date = formatter.date(from: value) ?? ISO8601DateFormatter().date(from: value) else {
            return ""
        }

        let display = DateFormatter()
        display.locale = Locale(identifier: "ja_JP")
        display.dateFormat = "HH:mm"
        return display.string(from: date)
    }

    private func formatFullDateTime(_ value: String) -> String {
        let formatter = ISO8601DateFormatter()
        formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        guard let date = formatter.date(from: value) ?? ISO8601DateFormatter().date(from: value) else {
            return value
        }

        let display = DateFormatter()
        display.locale = Locale(identifier: "ja_JP")
        display.dateFormat = "yyyy/MM/dd HH:mm:ss"
        return display.string(from: date)
    }

    private func loadMessages() {
        guard let userId = session.currentUserId, hasConversationTarget else { return }
        messageLoadGeneration += 1
        let generation = messageLoadGeneration
        isLoading = true
        Task {
            do {
                let fetched: [MessageDto]
                if let groupId {
                    fetched = try await APIClient.shared.fetchGroupMessages(userId: userId, groupId: groupId)
                } else {
                    fetched = try await APIClient.shared.fetchMessages(userId: userId, targetEmail: targetEmail)
                }
                guard generation == messageLoadGeneration else { return }
                self.messages = fetched
                PushNotificationManager.shared.clearMessageNotifications(
                    messageIds: fetched.map(\.id))
                self.errorMessage = nil
                self.isLoading = false
            } catch {
                guard generation == messageLoadGeneration else { return }
                self.errorMessage = error.localizedDescription
                self.isLoading = false
            }
        }
    }

    private func submitMessage() {
        if editingMessage != nil {
            editMessage()
        } else {
            sendMessage(silent: false)
        }
    }

    private func sendSilentMessage() {
        guard editingMessage == nil else { return }
        sendMessage(silent: true)
    }

    private func editMessage() {
        guard let userId = session.currentUserId,
              let editingMessage,
              !messageText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
        let contentToEdit = messageText.trimmingCharacters(in: .whitespacesAndNewlines)
        isSending = true
        Task {
            defer { isSending = false }
            do {
                if let groupId {
                    _ = try await APIClient.shared.editGroupMessage(
                        userId: userId,
                        groupId: groupId,
                        messageId: editingMessage.id,
                        content: contentToEdit)
                } else {
                    _ = try await APIClient.shared.editMessage(
                        userId: userId,
                        messageId: editingMessage.id,
                        content: contentToEdit)
                }
                self.editingMessage = nil
                messageText = ""
                loadMessages()
            } catch {
                errorMessage = error.localizedDescription
            }
        }
    }

    private func sendMessage(silent: Bool) {
        let contentToSend = messageText
        guard let userId = session.currentUserId,
              hasConversationTarget,
              !contentToSend.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
              !isSending else { return }
        stopTyping()
        let draftRevision = messageDraftRevision
        let replyToMessageId = replyToMessage?.id
        isSending = true

        Task {
            do {
                if let groupId {
                    _ = try await APIClient.shared.sendGroupMessage(
                        groupId: groupId,
                        request: SendGroupMessageRequest(
                            userId: userId,
                            content: contentToSend,
                            replyToMessageId: replyToMessageId,
                            silent: silent))
                } else {
                    let req = SendMessageRequest(
                        senderId: userId,
                        receiverEmail: targetEmail,
                        content: contentToSend,
                        profileId: profileId,
                        replyToMessageId: replyToMessageId,
                        silent: silent)
                    _ = try await APIClient.shared.sendMessage(request: req)
                }
                if messageDraftRevision == draftRevision && messageText == contentToSend {
                    messageText = ""
                }
                if replyToMessage?.id == replyToMessageId {
                    replyToMessage = nil
                }
                isSending = false
                loadMessages()
            } catch {
                self.errorMessage = error.localizedDescription
                isSending = false
            }
        }
    }
}
