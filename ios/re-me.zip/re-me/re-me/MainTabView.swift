import SwiftUI

private struct NotificationChatRoute: Hashable {
    let targetEmail: String?
    let groupId: String?
}

struct MainTabView: View {
    @ObservedObject private var session = AppSession.shared
    @ObservedObject private var pushNotifications = PushNotificationManager.shared
    @ObservedObject private var callManager = CallManager.shared
    @State private var selectedTab = "messages"
    @State private var chatPath = NavigationPath()
    @State private var handledUnclassifiedNotificationRevision = 0
    @State private var isShowingCallScreen = false
    @State private var isShowingCallError = false
    @AppStorage("translationSuggestionsEnabled") private var translationSuggestionsEnabled = true

    var body: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $selectedTab) {
                NavigationStack(path: $chatPath) {
                    ConversationListView()
                        .navigationDestination(for: NotificationChatRoute.self) { route in
                            ChatView(
                                targetEmail: route.targetEmail ?? "",
                                targetName: route.groupId == nil ? nil : "グループ",
                                groupId: route.groupId)
                        }
                }
                .tabItem {
                    Label("メッセージ", systemImage: "bubble.left.and.bubble.right")
                }
                .tag("messages")

                NavigationStack {
                    List {
                        Section {
                            LabeledContent("サインイン状態") {
                                Label("サインイン中", systemImage: "checkmark.circle.fill")
                                    .foregroundStyle(.green)
                            }
                        } header: {
                            Text("アカウント")
                        }

                        Section {
                            NavigationLink {
                                BlockedUsersView()
                            } label: {
                                Label("ブロック中", systemImage: "person.crop.circle.badge.xmark")
                            }
                        }

                        Section {
                            Toggle(isOn: $translationSuggestionsEnabled) {
                                Label("翻訳の提案", systemImage: "character.bubble")
                            }
                        } footer: {
                            Text("英語らしいメッセージに翻訳ボタンを表示します。")
                        }

                        Section {
                            Button(role: .destructive) {
                                session.logOut()
                            } label: {
                                Label("ログアウト", systemImage: "rectangle.portrait.and.arrow.right")
                            }
                        }
                    }
                    .listStyle(.insetGrouped)
                    .navigationTitle("アカウント")
                }
                .tabItem {
                    Label("アカウント", systemImage: "person.crop.circle")
                }
                .tag("account")
            }
            if callManager.isMinimized, let call = callManager.callScreen {
                Button {
                    callManager.restoreCall()
                } label: {
                    HStack(spacing: 10) {
                        Image(systemName: call.phase == .active ? "waveform" : "phone.fill")
                        VStack(alignment: .leading, spacing: 2) {
                            Text(call.peerName)
                                .font(.subheadline.weight(.semibold))
                            Text(call.phase == .active ? "通話中" : "接続中…")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                        Spacer()
                        Image(systemName: "chevron.up")
                    }
                    .padding(.horizontal, 16)
                    .padding(.vertical, 12)
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 16))
                    .shadow(radius: 8)
                }
                .buttonStyle(.plain)
                .padding(.horizontal, 16)
                .padding(.bottom, 8)
                .accessibilityLabel("通話画面を表示")
            }
        }
        .onAppear {
            openPendingNotificationChat()
        }
        .onChange(of: pushNotifications.tappedChatEmail) { _, email in
            if email != nil {
                openPendingNotificationChat()
            }
        }
        .onChange(of: pushNotifications.tappedGroupId) { _, groupId in
            if groupId != nil {
                openPendingNotificationChat()
            }
        }
        .onChange(of: pushNotifications.unclassifiedNotificationRevision) { _, _ in
            openPendingNotificationChat()
        }
        .fullScreenCover(isPresented: $isShowingCallScreen, onDismiss: {
            if callManager.callScreen != nil && !callManager.isMinimized {
                isShowingCallScreen = true
            } else {
                isShowingCallError = callManager.callErrorMessage != nil
            }
        }) {
            CallScreen()
                .interactiveDismissDisabled()
        }
        .onAppear {
            isShowingCallScreen = callManager.callScreen != nil && !callManager.isMinimized
        }
        .onChange(of: callManager.callScreen?.id) { _, callId in
            isShowingCallScreen = callId != nil && !callManager.isMinimized
            if callId == nil {
                isShowingCallError = callManager.callErrorMessage != nil
            }
        }
        .onChange(of: callManager.callErrorMessage) { _, message in
            if message != nil && callManager.callScreen == nil {
                isShowingCallError = true
            }
        }
        .onChange(of: callManager.isMinimized) { _, minimized in
            isShowingCallScreen = callManager.callScreen != nil && !minimized
        }
        .alert("通話エラー", isPresented: $isShowingCallError) {
            Button("OK", role: .cancel) { callManager.dismissError() }
        } message: {
            Text(callManager.callErrorMessage ?? "")
        }
    }

    private func openPendingNotificationChat() {
        selectedTab = "messages"
        chatPath = NavigationPath()
        if pushNotifications.unclassifiedNotificationRevision > handledUnclassifiedNotificationRevision {
            handledUnclassifiedNotificationRevision = pushNotifications.unclassifiedNotificationRevision
            return
        } else if let groupId = pushNotifications.tappedGroupId {
            chatPath.append(NotificationChatRoute(targetEmail: nil, groupId: groupId))
            pushNotifications.clearTappedGroupId()
        } else if let email = pushNotifications.tappedChatEmail {
            chatPath.append(NotificationChatRoute(targetEmail: email, groupId: nil))
            pushNotifications.clearTappedChatEmail()
        }
    }
}
