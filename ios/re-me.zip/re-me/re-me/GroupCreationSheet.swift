import SwiftUI

struct GroupCreationSheet: View {
    @Environment(\.dismiss) private var dismiss

    let userId: String
    let profileId: Int64
    let onCreated: () -> Void

    @State private var name = ""
    @State private var contacts: [GroupContactDto] = []
    @State private var selectedContactIds: Set<String> = []
    @State private var isLoading = true
    @State private var isCreating = false
    @State private var errorMessage: String?

    var body: some View {
        NavigationStack {
            Form {
                Section("グループ名") {
                    TextField("グループ名", text: $name)
                        .textInputAutocapitalization(.never)
                }

                Section {
                    if isLoading {
                        ProgressView("連絡先を読み込み中")
                    } else if contacts.isEmpty {
                        Text("このプロファイルに連絡先がありません。先に相手を追加してください。")
                            .foregroundStyle(.secondary)
                    } else {
                        ForEach(contacts) { contact in
                            Button {
                                if selectedContactIds.contains(contact.publicUserId) {
                                    selectedContactIds.remove(contact.publicUserId)
                                } else {
                                    selectedContactIds.insert(contact.publicUserId)
                                }
                            } label: {
                                HStack {
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(contact.displayName)
                                            .foregroundStyle(.primary)
                                        Text(contact.email)
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                    Spacer()
                                    Image(systemName: selectedContactIds.contains(contact.publicUserId)
                                          ? "checkmark.circle.fill" : "circle")
                                        .foregroundStyle(selectedContactIds.contains(contact.publicUserId)
                                                         ? Color.accentColor : Color.secondary)
                                }
                                .contentShape(Rectangle())
                            }
                            .buttonStyle(.plain)
                        }
                    }
                } header: {
                    Text("メンバー（自分以外に2人以上）")
                }

                if let errorMessage {
                    Section {
                        Text(errorMessage)
                            .foregroundStyle(.red)
                    }
                }
            }
            .navigationTitle("グループを作成")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("キャンセル") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(isCreating ? "作成中…" : "作成") {
                        createGroup()
                    }
                    .disabled(isLoading || isCreating
                              || name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                              || selectedContactIds.count < 2)
                }
            }
            .task {
                do {
                    contacts = try await APIClient.shared.fetchGroupContacts(
                        userId: userId, profileId: profileId)
                } catch {
                    errorMessage = error.localizedDescription
                }
                isLoading = false
            }
        }
    }

    private func createGroup() {
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty, selectedContactIds.count >= 2 else { return }
        isCreating = true
        Task {
            do {
                try await APIClient.shared.createGroup(
                    userId: userId,
                    profileId: profileId,
                    name: trimmedName,
                    memberPublicIds: Array(selectedContactIds))
                onCreated()
                dismiss()
            } catch {
                errorMessage = error.localizedDescription
                isCreating = false
            }
        }
    }
}
