import Foundation

// MARK: - Data Models
struct RegisterRequest: Encodable {
    let email: String
    let password: String
    let name: String
}

struct LoginRequest: Encodable {
    let email: String
    let password: String
}

struct AuthResponse: Decodable {
    let message: String
    let userId: String?
    let sessionToken: String?
}

struct CallInvitationResponse: Decodable {
    let callId: String
    let status: String
}

struct StartCallRequest: Encodable {
    let targetEmail: String
}

// MARK: - Message Models
struct SendMessageRequest: Encodable {
    let senderId: String
    let profileId: Int64?
    let replyToMessageId: Int64?
    let receiverEmail: String
    let content: String
    let silent: Bool

    init(
        senderId: String,
        receiverEmail: String,
        content: String,
        profileId: Int64? = nil,
        replyToMessageId: Int64? = nil,
        silent: Bool = false
    ) {
        self.senderId = senderId
        self.profileId = profileId
        self.replyToMessageId = replyToMessageId
        self.receiverEmail = receiverEmail
        self.content = content
        self.silent = silent
    }

}

struct CreateGroupRequest: Encodable {
    let userId: String
    let profileId: Int64
    let name: String
    let memberPublicIds: [String]
}

struct SendGroupMessageRequest: Encodable {
    let userId: String
    let content: String
    let replyToMessageId: Int64?
    let silent: Bool
}

struct MessageMentionDto: Decodable, Identifiable {
    let startIndex: Int
    let length: Int
    let userId: String
    let displayName: String
    let currentUser: Bool
    let everyone: Bool

    var id: String { "\(startIndex)-\(userId)" }
}

struct ManageGroupMembersRequest: Encodable {
    let userId: String
    let memberPublicIds: [String]
}

struct EditMessageRequest: Encodable {
    let userId: String
    let content: String
}

struct ChatProfileDto: Decodable, Identifiable, Hashable {
    let id: Int64
    let name: String
    let displayName: String
    let defaultProfile: Bool
}

struct MessageDto: Decodable, Identifiable {
    let id: Int64
    let senderId: String
    let senderEmail: String?
    let unclassifiedForReceiver: Bool?
    let notificationTitle: String?
    let notificationBody: String?
    let receiverId: String?
    let content: String
    let senderDisplayName: String?
    let replyToMessageId: Int64?
    let replyToContent: String?
    let replyToSenderName: String?
    let type: String?
    let callDurationSeconds: Int64?
    let edited: Bool?
    var readStatus: Bool?
    let readCount: Int?
    let createdAt: String
    let groupId: String?
    let groupName: String?
    let reactions: [MessageReactionDto]?
    let silent: Bool?
    let recalled: Bool?
    let notificationsMuted: Bool?
    let mentions: [MessageMentionDto]?
}

struct LibreTranslateRequest: Encodable {
    let q: String
    let source: String
    let target: String
    let format: String
}

struct LibreTranslateResponse: Decodable {
    let translatedText: String
}

struct MessageReactionDto: Decodable, Identifiable {
    let emoji: String
    let count: Int
    let reactedByMe: Bool

    var id: String { emoji }
}

private struct ToggleMessageReactionRequest: Encodable {
    let userId: String
    let emoji: String
}

struct GroupContactDto: Decodable, Identifiable, Hashable {
    let publicUserId: String
    let email: String
    let displayName: String

    var id: String { publicUserId }
}

struct GroupConversationDto: Decodable, Identifiable {
    let id: String
    let name: String
    let lastMessage: String
    let lastMessageTime: String?
    let unreadCount: Int
}

struct GroupMemberDto: Decodable, Identifiable {
    let publicUserId: String
    let email: String
    let displayName: String
    let username: String?
    let creator: Bool

    var id: String { publicUserId }
}

struct ConversationMuteDto: Decodable, Identifiable {
    let targetEmail: String?
    let groupId: String?
    let mode: String

    var id: String { groupId ?? targetEmail ?? mode }
}

private struct ConversationMuteRequest: Encodable {
    let userId: String
    let targetEmail: String?
    let groupId: String?
    let mode: String
}

struct BlockedUserDto: Decodable, Identifiable {
    let email: String
    let publicUserId: String
    let visibleProfileId: Int64?
    let visibleProfileName: String?

    var id: String { publicUserId }
}

struct OnlineStatusDto: Decodable {
    let visible: Bool
}

private struct UpdateOnlineStatusRequest: Encodable {
    let userId: String
    let visible: Bool
}

private struct UserBlockRequest: Encodable {
    let userId: String
    let targetEmail: String
}

private struct UpdateBlockedUserProfileRequest: Encodable {
    let userId: String
    let targetEmail: String
    let profileId: Int64
}

// ★ 追加: 会話一覧用データモデル
struct ConversationDto: Decodable, Identifiable {
    var id: String { targetEmail }
    let targetEmail: String
    let targetUserId: String?
    let targetName: String
    let lastMessage: String
    let updatedAt: String
    let unreadCount: Int

    private enum CodingKeys: String, CodingKey {
        case targetEmail
        case targetUserId
        case targetName
        case lastMessage
        case updatedAt
        case lastMessageTime
        case unreadCount
    }

    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        targetEmail = try container.decode(String.self, forKey: .targetEmail)
        targetUserId = try container.decodeIfPresent(String.self, forKey: .targetUserId)
        targetName = try container.decodeIfPresent(String.self, forKey: .targetName) ?? targetEmail
        lastMessage = try container.decode(String.self, forKey: .lastMessage)
        updatedAt = try container.decodeIfPresent(String.self, forKey: .updatedAt)
            ?? container.decodeIfPresent(String.self, forKey: .lastMessageTime)
            ?? ""
        unreadCount = try container.decodeIfPresent(Int.self, forKey: .unreadCount) ?? 0
    }
}

// MARK: - API Client
class APIClient {
    static let shared = APIClient()
    private init() {}
    
    private let baseURL = "https://nonphotographically-axiological-isaias.ngrok-free.dev"

    func messageWebSocketURL(userId: String) -> URL? {
        guard var components = URLComponents(string: baseURL) else { return nil }
        components.scheme = components.scheme == "https" ? "wss" : "ws"
        components.path = "/ws/messages"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        return components.url
    }
    
    func register(request: RegisterRequest) async throws -> AuthResponse {
        return try await performRequest(endpoint: "/api/auth/register", body: request)
    }
    
    func login(request: LoginRequest) async throws -> AuthResponse {
        return try await performRequest(endpoint: "/api/auth/login", body: request)
    }

    func revokeSession(sessionToken: String) async throws {
        try await performAuthorizedEmptyRequest(
            endpoint: "/api/auth/logout",
            method: "POST",
            sessionToken: sessionToken)
    }

    func startCall(sessionToken: String, targetEmail: String) async throws -> CallInvitationResponse {
        try await performAuthorizedRequest(
            endpoint: "/api/calls",
            method: "POST",
            sessionToken: sessionToken,
            body: try JSONEncoder().encode(StartCallRequest(targetEmail: targetEmail)))
    }

    func acceptCall(sessionToken: String, callId: String) async throws -> CallInvitationResponse {
        try await performAuthorizedRequest(
            endpoint: "/api/calls/\(callId)/accept",
            method: "POST",
            sessionToken: sessionToken)
    }

    func declineCall(sessionToken: String, callId: String) async throws {
        try await performAuthorizedEmptyRequest(
            endpoint: "/api/calls/\(callId)/decline",
            method: "POST",
            sessionToken: sessionToken)
    }

    func endCall(sessionToken: String, callId: String) async throws {
        try await performAuthorizedEmptyRequest(
            endpoint: "/api/calls/\(callId)/end",
            method: "POST",
            sessionToken: sessionToken)
    }

    func registerVoipToken(sessionToken: String, deviceToken: String) async throws {
        let body = VoipDeviceTokenRequest(deviceToken: deviceToken)
        try await performAuthorizedEmptyRequest(
            endpoint: "/api/devices/voip",
            method: "POST",
            sessionToken: sessionToken,
            body: try JSONEncoder().encode(body))
    }

    func unregisterVoipToken(sessionToken: String, deviceToken: String) async throws {
        guard var components = URLComponents(string: baseURL) else {
            throw URLError(.badURL)
        }
        components.path = "/api/devices/voip"
        components.queryItems = [URLQueryItem(name: "deviceToken", value: deviceToken)]
        guard let url = components.url else { throw URLError(.badURL) }
        var request = URLRequest(url: url)
        request.httpMethod = "DELETE"
        request.setValue("Bearer \(sessionToken)", forHTTPHeaderField: "Authorization")
        request.setValue("true", forHTTPHeaderField: "ngrok-skip-browser-warning")
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response: response, data: data)
    }
    
    func sendMessage(request: SendMessageRequest) async throws -> MessageDto {
        return try await performRequest(endpoint: "/api/messages", body: request)
    }

    func translateMessage(_ text: String) async throws -> String {
        guard let url = URL(string: "https://play.crafters.love/lt/translate") else {
            throw URLError(.badURL)
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.httpBody = try JSONEncoder().encode(
            LibreTranslateRequest(q: text, source: "en", target: "ja", format: "text"))

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse else {
            throw URLError(.cannotParseResponse)
        }
        guard (200...299).contains(httpResponse.statusCode) else {
            let message = String(data: data, encoding: .utf8) ?? "翻訳APIでエラーが発生しました"
            throw NSError(
                domain: "LibreTranslate",
                code: httpResponse.statusCode,
                userInfo: [NSLocalizedDescriptionKey: message])
        }

        let result = try JSONDecoder().decode(LibreTranslateResponse.self, from: data)
        guard !result.translatedText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            throw NSError(
                domain: "LibreTranslate",
                code: 0,
                userInfo: [NSLocalizedDescriptionKey: "翻訳結果が空でした"])
        }
        return result.translatedText
    }

    func fetchGroupContacts(userId: String, profileId: Int64) async throws -> [GroupContactDto] {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/groups/contacts"
        components.queryItems = [
            URLQueryItem(name: "userId", value: userId),
            URLQueryItem(name: "profileId", value: String(profileId))
        ]
        guard let url = components.url else { throw URLError(.badURL) }
        return try await fetchDecoded(url: url)
    }

    func createGroup(
        userId: String,
        profileId: Int64,
        name: String,
        memberPublicIds: [String]
    ) async throws {
        let body = CreateGroupRequest(
            userId: userId,
            profileId: profileId,
            name: name,
            memberPublicIds: memberPublicIds)
        let _: GroupConversationDto = try await performRequest(endpoint: "/api/groups", body: body)
    }

    func fetchGroups(userId: String) async throws -> [GroupConversationDto] {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/groups"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        return try await fetchDecoded(url: url)
    }

    func fetchGroupMessages(userId: String, groupId: String) async throws -> [MessageDto] {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/groups/\(groupId)/messages"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        return try await fetchDecoded(url: url)
    }

    func sendGroupMessage(groupId: String, request: SendGroupMessageRequest) async throws -> MessageDto {
        return try await performRequest(endpoint: "/api/groups/\(groupId)/messages", body: request)
    }

    func editGroupMessage(
        userId: String,
        groupId: String,
        messageId: Int64,
        content: String
    ) async throws -> MessageDto {
        let body = EditMessageRequest(userId: userId, content: content)
        return try await performRequest(
            endpoint: "/api/groups/\(groupId)/messages/\(messageId)",
            method: "PUT",
            body: body)
    }

    func toggleGroupMessageReaction(
        userId: String,
        groupId: String,
        messageId: Int64,
        emoji: String
    ) async throws {
        let body = ToggleMessageReactionRequest(userId: userId, emoji: emoji)
        try await performEmptyRequest(
            endpoint: "/api/groups/\(groupId)/messages/\(messageId)/reactions",
            method: "POST",
            body: body)
    }

    func recallGroupMessage(userId: String, groupId: String, messageId: Int64) async throws {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/groups/\(groupId)/messages/\(messageId)"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        try await performEmptyRequest(url: url, method: "DELETE")
    }

    func markGroupAsRead(userId: String, groupId: String) async throws {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/groups/\(groupId)/read"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        try await performEmptyRequest(url: url, method: "PUT")
    }

    func fetchGroupMembers(userId: String, groupId: String) async throws -> [GroupMemberDto] {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/groups/\(groupId)/members"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        return try await fetchDecoded(url: url)
    }

    func addGroupMembers(userId: String, groupId: String, publicUserIds: [String]) async throws {
        let body = ManageGroupMembersRequest(userId: userId, memberPublicIds: publicUserIds)
        let _: [GroupMemberDto] = try await performRequest(
            endpoint: "/api/groups/\(groupId)/members",
            body: body)
    }

    func removeGroupMember(userId: String, groupId: String, memberPublicId: String) async throws {
        try await groupMemberRequest(
            userId: userId,
            groupId: groupId,
            path: "/members/\(memberPublicId)")
    }

    func leaveGroup(userId: String, groupId: String) async throws {
        try await groupMemberRequest(userId: userId, groupId: groupId, path: "/members/me")
    }

    func deleteGroup(userId: String, groupId: String) async throws {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/groups/\(groupId)"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        try await performEmptyRequest(url: url, method: "DELETE")
    }

    func leaveConversation(userId: String, targetEmail: String, profileId: Int64?) async throws {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/messages/leave"
        var queryItems = [
            URLQueryItem(name: "userId", value: userId),
            URLQueryItem(name: "targetEmail", value: targetEmail)
        ]
        if let profileId {
            queryItems.append(URLQueryItem(name: "profileId", value: String(profileId)))
        }
        components.queryItems = queryItems
        guard let url = components.url else { throw URLError(.badURL) }
        try await performEmptyRequest(url: url, method: "DELETE")
    }

    func editMessage(userId: String, messageId: Int64, content: String) async throws -> MessageDto {
        let body = EditMessageRequest(userId: userId, content: content)
        return try await performRequest(
            endpoint: "/api/messages/\(messageId)",
            method: "PUT",
            body: body)
    }

    func toggleMessageReaction(userId: String, messageId: Int64, emoji: String) async throws {
        let body = ToggleMessageReactionRequest(userId: userId, emoji: emoji)
        try await performEmptyRequest(
            endpoint: "/api/messages/\(messageId)/reactions",
            method: "POST",
            body: body)
    }

    func recallMessage(userId: String, messageId: Int64) async throws {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/messages/\(messageId)"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        try await performEmptyRequest(url: url, method: "DELETE")
    }

    func registerAPNsToken(userId: String, deviceToken: String) async throws {
        let body = ApnsDeviceTokenRequest(userId: userId, deviceToken: deviceToken)
        try await performEmptyRequest(endpoint: "/api/devices/apns", method: "POST", body: body)
    }

    func unregisterAPNsToken(userId: String, deviceToken: String) async throws {
        guard var components = URLComponents(string: baseURL) else {
            throw URLError(.badURL)
        }
        components.path = "/api/devices/apns"
        components.queryItems = [
            URLQueryItem(name: "userId", value: userId),
            URLQueryItem(name: "deviceToken", value: deviceToken)
        ]
        guard let url = components.url else {
            throw URLError(.badURL)
        }
        try await performEmptyRequest(url: url, method: "DELETE")
    }
    
    func fetchMessages(userId: String, targetEmail: String) async throws -> [MessageDto] {
        guard let encodedEmail = targetEmail.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "\(baseURL)/api/messages?userId=\(userId)&targetEmail=\(encodedEmail)") else {
            throw URLError(.badURL)
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("true", forHTTPHeaderField: "ngrok-skip-browser-warning")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            let errorMsg = String(data: data, encoding: .utf8) ?? "エラーが発生しました"
            throw NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: errorMsg])
        }
        
        return try JSONDecoder().decode([MessageDto].self, from: data)
    }

    func fetchUnreadMessageCount(userId: String) async throws -> Int {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/messages/unread-count"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        return try await fetchDecoded(url: url)
    }

    func fetchConversationMutes(userId: String) async throws -> [ConversationMuteDto] {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/messages/mutes"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        return try await fetchDecoded(url: url)
    }

    func updateConversationMute(
        userId: String,
        targetEmail: String? = nil,
        groupId: String? = nil,
        mode: String
    ) async throws {
        let body = ConversationMuteRequest(
            userId: userId,
            targetEmail: targetEmail,
            groupId: groupId,
            mode: mode)
        try await performEmptyRequest(
            endpoint: "/api/messages/mute",
            method: "PUT",
            body: body)
    }

    func fetchBlockedUsers(userId: String) async throws -> [BlockedUserDto] {
        guard var components = URLComponents(string: baseURL) else {
            throw URLError(.badURL)
        }
        components.path = "/api/messages/blocks"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        return try await fetchDecoded(url: url)
    }

    func fetchOnlineStatus(userId: String) async throws -> Bool {
        guard var components = URLComponents(string: baseURL) else {
            throw URLError(.badURL)
        }
        components.path = "/api/users/online-status"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        let status: OnlineStatusDto = try await fetchDecoded(url: url)
        return status.visible
    }

    func updateOnlineStatus(userId: String, visible: Bool) async throws {
        try await performEmptyRequest(
            endpoint: "/api/users/online-status",
            method: "PUT",
            body: UpdateOnlineStatusRequest(userId: userId, visible: visible))
    }

    func blockUser(userId: String, targetEmail: String) async throws {
        try await performEmptyRequest(
            endpoint: "/api/messages/blocks",
            method: "POST",
            body: UserBlockRequest(userId: userId, targetEmail: targetEmail))
    }

    func unblockUser(userId: String, targetEmail: String) async throws {
        guard var components = URLComponents(string: baseURL) else {
            throw URLError(.badURL)
        }
        components.path = "/api/messages/blocks"
        components.queryItems = [
            URLQueryItem(name: "userId", value: userId),
            URLQueryItem(name: "targetEmail", value: targetEmail)
        ]
        guard let url = components.url else { throw URLError(.badURL) }
        try await performEmptyRequest(url: url, method: "DELETE")
    }

    func updateBlockedUserProfile(
        userId: String,
        targetEmail: String,
        profileId: Int64
    ) async throws {
        try await performEmptyRequest(
            endpoint: "/api/messages/blocks/profile",
            method: "PUT",
            body: UpdateBlockedUserProfileRequest(
                userId: userId,
                targetEmail: targetEmail,
                profileId: profileId))
    }
    
    // ★ 追加: 会話一覧取得メソッド
    func fetchConversations(userId: String) async throws -> [ConversationDto] {
        guard var components = URLComponents(string: baseURL) else {
            throw URLError(.badURL)
        }
        components.path = "/api/messages/conversations"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        return try await fetchConversations(url: url)
    }

    func fetchConversations(userId: String, profileId: Int64) async throws -> [ConversationDto] {
        guard var components = URLComponents(string: baseURL) else {
            throw URLError(.badURL)
        }
        components.path = "/api/messages/conversations"
        components.queryItems = [
            URLQueryItem(name: "userId", value: userId),
            URLQueryItem(name: "profileId", value: String(profileId))
        ]
        guard let url = components.url else { throw URLError(.badURL) }
        return try await fetchConversations(url: url)
    }

    func fetchUnclassifiedConversations(userId: String) async throws -> [ConversationDto] {
        guard var components = URLComponents(string: baseURL) else {
            throw URLError(.badURL)
        }
        components.path = "/api/messages/conversations"
        components.queryItems = [
            URLQueryItem(name: "userId", value: userId),
            URLQueryItem(name: "unclassified", value: "true")
        ]
        guard let url = components.url else { throw URLError(.badURL) }
        return try await fetchConversations(url: url)
    }

    private func fetchConversations(url: URL) async throws -> [ConversationDto] {
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("true", forHTTPHeaderField: "ngrok-skip-browser-warning")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            let errorMsg = String(data: data, encoding: .utf8) ?? "エラーが発生しました"
            throw NSError(domain: "", code: 0, userInfo: [NSLocalizedDescriptionKey: errorMsg])
        }
        
        return try JSONDecoder().decode([ConversationDto].self, from: data)
    }

    private func fetchDecoded<T: Decodable>(url: URL) async throws -> T {
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("true", forHTTPHeaderField: "ngrok-skip-browser-warning")
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response: response, data: data)
        return try JSONDecoder().decode(T.self, from: data)
    }

    private func groupMemberRequest(userId: String, groupId: String, path: String) async throws {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/groups/\(groupId)\(path)"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        try await performEmptyRequest(url: url, method: "DELETE")
    }

    func fetchChatProfiles(userId: String) async throws -> [ChatProfileDto] {
        guard var components = URLComponents(string: baseURL) else {
            throw URLError(.badURL)
        }
        components.path = "/api/profiles"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("true", forHTTPHeaderField: "ngrok-skip-browser-warning")
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response: response, data: data)
        return try JSONDecoder().decode([ChatProfileDto].self, from: data)
    }

    func createChatProfile(userId: String, name: String) async throws {
        let body = CreateChatProfileRequest(userId: userId, name: name)
        try await performEmptyRequest(endpoint: "/api/profiles", method: "POST", body: body)
    }

    func updateChatProfileDisplayName(userId: String, profileId: Int64, displayName: String) async throws {
        let body = UpdateChatProfileIdentityRequest(userId: userId, displayName: displayName)
        let _: ChatProfileDto = try await performRequest(
            endpoint: "/api/profiles/\(profileId)/identity",
            method: "PUT",
            body: body)
    }

    func deleteChatProfile(userId: String, profileId: Int64) async throws {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/profiles/\(profileId)"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        try await performEmptyRequest(url: url, method: "DELETE")
    }

    func addProfileContact(userId: String, profileId: Int64, email: String) async throws {
        let body = AddProfileContactRequest(userId: userId, email: email)
        try await performEmptyRequest(
            endpoint: "/api/profiles/\(profileId)/contacts", method: "POST", body: body)
    }

    func addProfileContact(userId: String, profileId: Int64, publicUserId: String) async throws {
        guard var components = URLComponents(string: baseURL) else {
            throw URLError(.badURL)
        }
        components.path = "/api/profiles/\(profileId)/contacts/by-user/\(publicUserId)"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        try await performEmptyRequest(url: url, method: "POST")
    }

    func assignContact(userId: String, profileId: Int64, contactUserId: String) async throws {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/profiles/\(profileId)/contacts/\(contactUserId)"
        components.queryItems = [URLQueryItem(name: "userId", value: userId)]
        guard let url = components.url else { throw URLError(.badURL) }
        try await performEmptyRequest(url: url, method: "PUT")
    }

    func deleteConversation(
        userId: String,
        targetUserId: String,
        profileId: Int64?,
        deleteForBoth: Bool
    ) async throws {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/messages/conversation"
        var queryItems = [
            URLQueryItem(name: "userId", value: userId),
            URLQueryItem(name: "targetUserId", value: targetUserId),
            URLQueryItem(name: "deleteForBoth", value: String(deleteForBoth))
        ]
        if let profileId {
            queryItems.append(URLQueryItem(name: "profileId", value: String(profileId)))
        }
        components.queryItems = queryItems
        guard let url = components.url else { throw URLError(.badURL) }
        try await performEmptyRequest(url: url, method: "DELETE")
    }

    func deleteConversation(
        userId: String,
        targetEmail: String,
        profileId: Int64?,
        deleteForBoth: Bool
    ) async throws {
        guard var components = URLComponents(string: baseURL) else { throw URLError(.badURL) }
        components.path = "/api/messages/conversation/by-email"
        var queryItems = [
            URLQueryItem(name: "userId", value: userId),
            URLQueryItem(name: "targetEmail", value: targetEmail),
            URLQueryItem(name: "deleteForBoth", value: String(deleteForBoth))
        ]
        if let profileId {
            queryItems.append(URLQueryItem(name: "profileId", value: String(profileId)))
        }
        components.queryItems = queryItems
        guard let url = components.url else { throw URLError(.badURL) }
        try await performEmptyRequest(url: url, method: "DELETE")
    }

    func fetchContactDisplayName(userId: String, contactEmail: String) async throws -> String {
        guard var components = URLComponents(string: baseURL) else {
            throw URLError(.badURL)
        }
        components.path = "/api/profiles/contacts/display-name"
        components.queryItems = [
            URLQueryItem(name: "userId", value: userId),
            URLQueryItem(name: "contactEmail", value: contactEmail)
        ]
        guard let url = components.url else {
            throw URLError(.badURL)
        }
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("true", forHTTPHeaderField: "ngrok-skip-browser-warning")
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response: response, data: data)
        return try JSONDecoder().decode(UserDisplayNameResponse.self, from: data).displayName
    }

    func fetchContactUsername(userId: String, contactEmail: String) async throws -> String {
        guard var components = URLComponents(string: baseURL) else {
            throw URLError(.badURL)
        }
        components.path = "/api/profiles/contacts/username"
        components.queryItems = [
            URLQueryItem(name: "userId", value: userId),
            URLQueryItem(name: "contactEmail", value: contactEmail)
        ]
        guard let url = components.url else { throw URLError(.badURL) }
        let response: UserNameResponse = try await fetchDecoded(url: url)
        return response.username
    }

    func markConversationAsRead(userId: String, targetEmail: String) async throws {
        guard var components = URLComponents(string: baseURL) else {
            throw URLError(.badURL)
        }
        components.path = "/api/messages/read"
        components.queryItems = [
            URLQueryItem(name: "userId", value: userId),
            URLQueryItem(name: "targetEmail", value: targetEmail)
        ]
        guard let url = components.url else {
            throw URLError(.badURL)
        }
        try await performEmptyRequest(url: url, method: "PUT")
    }
    
    private func performRequest<T: Encodable, U: Decodable>(
        endpoint: String,
        method: String = "POST",
        body: T
    ) async throws -> U {
        guard let url = URL(string: baseURL + endpoint) else {
            throw URLError(.badURL)
        }
        
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("true", forHTTPHeaderField: "ngrok-skip-browser-warning")
        
        request.httpBody = try JSONEncoder().encode(body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw URLError(.cannotParseResponse)
        }
        
        if (200...299).contains(httpResponse.statusCode) {
            return try JSONDecoder().decode(U.self, from: data)
        } else {
            let errorMsg = String(data: data, encoding: .utf8) ?? "エラーが発生しました"
            throw NSError(domain: "", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: errorMsg])
        }
    }

    private func performEmptyRequest<T: Encodable>(
        endpoint: String,
        method: String,
        body: T
    ) async throws {
        guard let url = URL(string: baseURL + endpoint) else {
            throw URLError(.badURL)
        }
        let encodedBody = try JSONEncoder().encode(body)
        try await performEmptyRequest(url: url, method: method, body: encodedBody)
    }

    private func performEmptyRequest(url: URL, method: String, body: Data? = nil) async throws {
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("true", forHTTPHeaderField: "ngrok-skip-browser-warning")
        if let body {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = body
        }

        let (data, response) = try await URLSession.shared.data(for: request)
        guard let httpResponse = response as? HTTPURLResponse else {
            throw URLError(.cannotParseResponse)
        }
        guard (200...299).contains(httpResponse.statusCode) else {
            let errorMsg = String(data: data, encoding: .utf8) ?? "エラーが発生しました"
            throw NSError(domain: "", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: errorMsg])
        }
    }

    private func performAuthorizedRequest<T: Decodable>(
        endpoint: String,
        method: String,
        sessionToken: String,
        body: Data? = nil
    ) async throws -> T {
        guard let url = URL(string: baseURL + endpoint) else {
            throw URLError(.badURL)
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("Bearer \(sessionToken)", forHTTPHeaderField: "Authorization")
        request.setValue("true", forHTTPHeaderField: "ngrok-skip-browser-warning")
        if let body {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = body
        }

        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response: response, data: data)
        return try JSONDecoder().decode(T.self, from: data)
    }

    private func performAuthorizedEmptyRequest(
        endpoint: String,
        method: String,
        sessionToken: String,
        body: Data? = nil
    ) async throws {
        guard let url = URL(string: baseURL + endpoint) else {
            throw URLError(.badURL)
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue("Bearer \(sessionToken)", forHTTPHeaderField: "Authorization")
        request.setValue("true", forHTTPHeaderField: "ngrok-skip-browser-warning")
        if let body {
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.httpBody = body
        }
        let (data, response) = try await URLSession.shared.data(for: request)
        try validate(response: response, data: data)
    }

    private func validate(response: URLResponse, data: Data) throws {
        guard let httpResponse = response as? HTTPURLResponse else {
            throw URLError(.cannotParseResponse)
        }
        guard (200...299).contains(httpResponse.statusCode) else {
            let errorMsg = String(data: data, encoding: .utf8) ?? "エラーが発生しました"
            throw NSError(domain: "", code: httpResponse.statusCode, userInfo: [NSLocalizedDescriptionKey: errorMsg])
        }
    }

    private struct ApnsDeviceTokenRequest: Encodable {
        let userId: String
        let deviceToken: String
    }

    private struct VoipDeviceTokenRequest: Encodable {
        let deviceToken: String
    }

    private struct CreateChatProfileRequest: Encodable {
        let userId: String
        let name: String
    }

    private struct UpdateChatProfileIdentityRequest: Encodable {
        let userId: String
        let displayName: String
    }

    private struct AddProfileContactRequest: Encodable {
        let userId: String
        let email: String
    }

    private struct UserDisplayNameResponse: Decodable {
        let displayName: String
    }

    private struct UserNameResponse: Decodable {
        let username: String
    }
}
