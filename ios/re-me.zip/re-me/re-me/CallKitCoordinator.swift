import AVFAudio
import CallKit
import Foundation
@preconcurrency import WebRTC

@MainActor
final class CallKitCoordinator: NSObject {
    static let shared = CallKitCoordinator()

    private struct CallDetails {
        let callId: String
        let peerName: String
        let peerEmail: String
        let isOutgoing: Bool
    }

    private let provider: CXProvider
    private let controller = CXCallController()
    private var callsByUUID: [UUID: CallDetails] = [:]
    private var uuidsByCallId: [String: UUID] = [:]

    private override init() {
        let configuration = CXProviderConfiguration(localizedName: "Re:Me")
        configuration.supportsVideo = false
        configuration.maximumCallGroups = 1
        configuration.maximumCallsPerCallGroup = 1
        configuration.supportedHandleTypes = [.generic]
        provider = CXProvider(configuration: configuration)
        super.init()
        provider.setDelegate(self, queue: .main)
    }

    func reportIncomingCall(
        callId: String,
        callerName: String,
        callerEmail: String,
        completion: @escaping () -> Void
    ) {
        let uuid = uuid(for: callId, name: callerName, email: callerEmail, isOutgoing: false)
        let update = CXCallUpdate()
        update.localizedCallerName = callerName
        update.remoteHandle = CXHandle(type: .generic, value: callerEmail)
        update.hasVideo = false
        provider.reportNewIncomingCall(with: uuid, update: update) { [weak self] error in
            if let error {
                NSLog("Failed to report incoming CallKit call: %@", error.localizedDescription)
                Task { @MainActor in
                    await CallManager.shared.rejectIncomingCallAfterCallKitFailure(callId: callId)
                    self?.forget(callId: callId)
                }
            }
            completion()
        }
    }

    func startOutgoingCall(callId: String, peerName: String, peerEmail: String) async throws {
        let uuid = uuid(for: callId, name: peerName, email: peerEmail, isOutgoing: true)
        let action = CXStartCallAction(
            call: uuid,
            handle: CXHandle(type: .generic, value: peerEmail))
        do {
            try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
                controller.request(CXTransaction(action: action)) { error in
                    if let error {
                        continuation.resume(throwing: error)
                    } else {
                        continuation.resume()
                    }
                }
            }
        } catch {
            forget(callId: callId)
            throw error
        }
    }

    func requestAnswerCall(callId: String) async throws {
        guard let uuid = uuidsByCallId[callId] else {
            throw callKitError("CallKit着信の状態を確認できません。")
        }
        try await request(CXAnswerCallAction(call: uuid))
    }

    func requestEndCall(callId: String) async throws {
        guard let uuid = uuidsByCallId[callId] else {
            throw callKitError("CallKit通話の状態を確認できません。")
        }
        try await request(CXEndCallAction(call: uuid))
    }

    func requestMute(callId: String, muted: Bool) async throws {
        guard let uuid = uuidsByCallId[callId] else {
            throw callKitError("CallKit通話の状態を確認できません。")
        }
        try await request(CXSetMutedCallAction(call: uuid, muted: muted))
    }

    private func request(_ action: CXCallAction) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            controller.request(CXTransaction(action: action)) { error in
                if let error {
                    continuation.resume(throwing: error)
                } else {
                    continuation.resume()
                }
            }
        }
    }

    private func callKitError(_ message: String) -> NSError {
        NSError(domain: "CallKitCoordinator", code: 1, userInfo: [NSLocalizedDescriptionKey: message])
    }

    func reportConnecting(callId: String) {
        guard let uuid = uuidsByCallId[callId],
              callsByUUID[uuid]?.isOutgoing == true else { return }
        provider.reportOutgoingCall(with: uuid, startedConnectingAt: Date())
    }

    func reportConnected(callId: String) {
        guard let uuid = uuidsByCallId[callId],
              callsByUUID[uuid]?.isOutgoing == true else { return }
        provider.reportOutgoingCall(with: uuid, connectedAt: Date())
    }

    func reportEnded(callId: String) {
        guard let uuid = uuidsByCallId[callId] else { return }
        provider.reportCall(with: uuid, endedAt: Date(), reason: .remoteEnded)
        forget(callId: callId)
    }

    private func uuid(
        for callId: String,
        name: String,
        email: String,
        isOutgoing: Bool
    ) -> UUID {
        if let uuid = uuidsByCallId[callId] {
            return uuid
        }
        let uuid = UUID(uuidString: callId) ?? UUID()
        callsByUUID[uuid] = CallDetails(
            callId: callId,
            peerName: name,
            peerEmail: email,
            isOutgoing: isOutgoing)
        uuidsByCallId[callId] = uuid
        return uuid
    }

    private func forget(callId: String) {
        guard let uuid = uuidsByCallId.removeValue(forKey: callId) else { return }
        callsByUUID.removeValue(forKey: uuid)
    }
}

extension CallKitCoordinator: CXProviderDelegate {
    func providerDidReset(_ provider: CXProvider) {
        let callIds = callsByUUID.values.map(\.callId)
        callsByUUID.removeAll()
        uuidsByCallId.removeAll()
        for callId in callIds {
            Task { await CallManager.shared.finishAfterCallKitReset(callId: callId) }
        }
    }

    func provider(_ provider: CXProvider, perform action: CXStartCallAction) {
        guard let details = callsByUUID[action.callUUID] else {
            action.fail()
            return
        }
        CallManager.shared.beginOutgoingCall(
            callId: details.callId,
            peerName: details.peerName,
            peerEmail: details.peerEmail)
        action.fulfill()
    }

    func provider(_ provider: CXProvider, perform action: CXAnswerCallAction) {
        guard let details = callsByUUID[action.callUUID] else {
            action.fail()
            return
        }
        Task {
            do {
                try await CallManager.shared.answerIncomingCall()
                action.fulfill()
            } catch {
                action.fail()
            }
        }
    }

    func provider(_ provider: CXProvider, perform action: CXEndCallAction) {
        guard let details = callsByUUID[action.callUUID] else {
            action.fulfill()
            return
        }
        Task {
            await CallManager.shared.endFromCallKit()
            forget(callId: details.callId)
            action.fulfill()
        }
    }

    func provider(_ provider: CXProvider, perform action: CXSetMutedCallAction) {
        CallManager.shared.setMuted(action.isMuted)
        action.fulfill()
    }

    func provider(_ provider: CXProvider, didActivate audioSession: AVAudioSession) {
        RTCAudioSession.sharedInstance().audioSessionDidActivate(audioSession)
    }

    func provider(_ provider: CXProvider, didDeactivate audioSession: AVAudioSession) {
        RTCAudioSession.sharedInstance().audioSessionDidDeactivate(audioSession)
    }
}
