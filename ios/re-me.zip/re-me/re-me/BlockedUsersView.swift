import SwiftUI

struct BlockedUsersView: View {
    @ObservedObject private var session = AppSession.shared
    @State private var blockedUsers: [BlockedUserDto] = []
    @State private var profiles: [ChatProfileDto] = []
    @State private var isLoading = false
    @State private var errorMessage: String?

    var body: some View {
        Group {
            if isLoading && blockedUsers.isEmpty {
                ProgressView("ブロック中のユーザーを読み込み中")
            } else if blockedUsers.isEmpty {
                ContentUnavailableView(
                    "ブロック中のユーザーはいません",
                    systemImage: "person.crop.circle.badge.checkmark")
            } else {
                List {
                    ForEach(blockedUsers) { blockedUser in
                        Section {
                            Picker(
                                "相手に見せるプロファイル",
                                selection: profileSelection(for: blockedUser)) {
                                ForEach(profiles) { profile in
                                    Text("\(profile.name) — \(profile.displayName)")
                                        .tag(Optional(profile.id))
                                }
                            }
                        } header: {
                            Label(blockedUser.email, systemImage: "person.crop.circle.badge.xmark")
                                .textCase(nil)
                        } footer: {
                            Text("この設定はブロックした相手に表示するプロファイルを決めます。")
                        }
                    }
                }
                .listStyle(.insetGrouped)
            }
        }
        .navigationTitle("ブロック中")
        .overlay {
            if let errorMessage {
                Text(errorMessage)
                    .foregroundStyle(.red)
                    .padding()
                    .background(.regularMaterial, in: RoundedRectangle(cornerRadius: 12))
            }
        }
        .task {
            await load()
        }
    }

    private func profileSelection(for blockedUser: BlockedUserDto) -> Binding<Int64?> {
        Binding(
            get: { blockedUser.visibleProfileId },
            set: { profileId in
                guard let profileId, let userId = session.currentUserId else { return }
                Task {
                    do {
                        try await APIClient.shared.updateBlockedUserProfile(
                            userId: userId,
                            targetEmail: blockedUser.email,
                            profileId: profileId)
                        await load()
                    } catch {
                        errorMessage = "表示プロファイルを保存できませんでした: \(error.localizedDescription)"
                    }
                }
            })
    }

    @MainActor
    private func load() async {
        guard let userId = session.currentUserId else { return }
        isLoading = true
        defer { isLoading = false }
        do {
            async let fetchedUsers = APIClient.shared.fetchBlockedUsers(userId: userId)
            async let fetchedProfiles = APIClient.shared.fetchChatProfiles(userId: userId)
            blockedUsers = try await fetchedUsers
            profiles = try await fetchedProfiles
            errorMessage = nil
        } catch {
            errorMessage = "ブロック中一覧を読み込めませんでした: \(error.localizedDescription)"
        }
    }
}
