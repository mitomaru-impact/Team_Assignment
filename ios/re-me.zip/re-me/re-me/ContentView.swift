import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = AuthViewModel()

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    if viewModel.isRegisterMode {
                        TextField("名前", text: $viewModel.name)
                            .textContentType(.name)
                            .textInputAutocapitalization(.words)
                            .autocorrectionDisabled()
                    }

                    TextField("メールアドレス", text: $viewModel.email)
                        .textContentType(.emailAddress)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()

                    SecureField("パスワード", text: $viewModel.password)
                        .textContentType(viewModel.isRegisterMode ? .newPassword : .password)
                } footer: {
                    Text(viewModel.isRegisterMode
                         ? "登録したメールアドレスとパスワードでサインインできます。"
                         : "登録したメールアドレスとパスワードを入力してください。")
                }

                Section {
                    Button {
                        viewModel.submit()
                    } label: {
                        HStack {
                            Spacer()
                            if viewModel.isLoading {
                                ProgressView()
                            } else {
                                Text(viewModel.isRegisterMode ? "アカウントを作成" : "サインイン")
                                    .fontWeight(.semibold)
                            }
                            Spacer()
                        }
                    }
                    .disabled(viewModel.isLoading)

                    Button(viewModel.isRegisterMode ? "アカウントをお持ちの方はこちら" : "アカウントを作成") {
                        viewModel.isRegisterMode.toggle()
                    }
                    .frame(maxWidth: .infinity)
                    .disabled(viewModel.isLoading)
                }
            }
            .scrollDismissesKeyboard(.interactively)
            .navigationTitle(viewModel.isRegisterMode ? "アカウント作成" : "サインイン")
            .navigationBarTitleDisplayMode(.large)
            .alert("エラー", isPresented: $viewModel.showAlert) {
                Button("OK", role: .cancel) {}
            } message: {
                Text(viewModel.alertMessage ?? "")
            }
        }
    }
}
